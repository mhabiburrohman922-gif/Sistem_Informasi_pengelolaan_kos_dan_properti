<?php
// Deteksi URI saat ini untuk mengaktifkan class .active secara akurat dan dinamis
$current_uri = $_SERVER['REQUEST_URI'];

// Tentukan base URL proyek agar link tidak pecah saat berpindah folder
$base_url = "/manajemen_kos";
?>

<style>
    /* Mengaktifkan scroll vertikal hanya di dalam list menu ul */
    #sidebar ul.components {
        max-height: calc(100vh - 90px); /* Membatasi tinggi menu agar pas dengan layar browser */
        overflow-y: auto;
        padding-bottom: 40px;
    }

    /* Modifikasi scrollbar agar tipis transparan dan estetik */
    #sidebar ul.components::-webkit-scrollbar {
        width: 4px;
    }
    #sidebar ul.components::-webkit-scrollbar-track {
        background: transparent;
    }
    #sidebar ul.components::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, 0.15);
        border-radius: 10px;
    }
    #sidebar ul.components::-webkit-scrollbar-thumb:hover {
        background: rgba(255, 255, 255, 0.3);
    }

    /* Kunci Responsif Mobile via CSS */
    @media (max-width: 768px) {
        #sidebar {
            margin-left: -250px;
            position: fixed;
            z-index: 999;
            height: 100vh;
        }
        #sidebar.active {
            margin-left: 0;
        }
        #content {
            width: 100% !important;
        }
    }
</style>

<nav id="sidebar">
    <div class="sidebar-header d-flex align-items-center justify-content-between">
        <h4 class="mb-0 fw-bold text-white"><i class="fa-solid fa-chart-pie me-2 text-primary"></i>KOSCLOVER</h4>
        <div class="logo-icon d-none text-center w-100">
            <i class="fa-solid fa-chart-pie fs-3 text-primary"></i>
        </div>
    </div>

    <ul class="list-unstyled components">
        
        <p class="sidebar-heading">Dashboard</p>
        <li class="<?= (strpos($current_uri, '/dashboard.php') !== false || $current_uri == $base_url . '/' || $current_uri == $base_url . '/index.php') ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/dashboard.php">
                <i class="fa-solid fa-house menu-i"></i>
                <span class="menu-text">Dashboard Main</span>
            </a>
        </li>

        <p class="sidebar-heading">Master Data</p>
        
        <li class="<?= (strpos($current_uri, '/kamar/') !== false) ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/kamar/index.php">
                <i class="fa-solid fa-door-open menu-i"></i>
                <span class="menu-text">Manajemen Kamar</span>
            </a>
        </li>
        
        <li class="<?= (strpos($current_uri, '/tipe_kamar/') !== false) ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/tipe_kamar/index.php">
                <i class="fa-solid fa-bed menu-i"></i>
                <span class="menu-text">Tipe Kamar</span>
            </a>
        </li>
        
        <li class="<?= (strpos($current_uri, '/penyewa/') !== false) ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/penyewa/index.php">
                <i class="fa-solid fa-users menu-i"></i>
                <span class="menu-text">Data Penyewa</span>
            </a>
        </li>
        
        <li class="<?= (strpos($current_uri, '/teknisi/') !== false) ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/teknisi/index.php">
                <i class="fa-solid fa-screwdriver-wrench menu-i"></i>
                <span class="menu-text">Data Teknisi</span>
            </a>
        </li>
        
        <li class="<?= (strpos($current_uri, '/daftar_tunggu/') !== false) ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/daftar_tunggu/index.php">
                <i class="fa-solid fa-hourglass-half menu-i"></i>
                <span class="menu-text">Daftar Tunggu</span>
            </a>
        </li>

        <p class="sidebar-heading">Transaksi</p>
        
        <li class="<?= (strpos($current_uri, '/kontrak_sewa/') !== false) ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/kontrak_sewa/index.php">
                <i class="fa-solid fa-file-signature menu-i"></i>
                <span class="menu-text">Kontrak Sewa</span>
            </a>
        </li>
        
        <li class="<?= (strpos($current_uri, '/tagihan_sewa/') !== false) ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/tagihan_sewa/index.php">
                <i class="fa-solid fa-file-invoice-dollar menu-i"></i>
                <span class="menu-text">Tagihan Sewa</span>
            </a>
        </li>
        
        <li class="<?= (strpos($current_uri, '/pembayaran/') !== false || strpos($current_uri, '/transaksi/pembayaran.php') !== false) ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/pembayaran/index.php">
                <i class="fa-solid fa-wallet menu-i"></i>
                <span class="menu-text">Pembayaran</span>
            </a>
        </li>
        
        <li class="<?= (strpos($current_uri, '/perbaikan/') !== false || strpos($current_uri, '/transaksi/perbaikan.php') !== false) ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/perbaikan/index.php">
                <i class="fa-solid fa-tools menu-i"></i>
                <span class="menu-text">Permintaan Perbaikan</span>
            </a>
        </li>

        <p class="sidebar-heading">Laporan</p>
        <li class="<?= (strpos($current_uri, '/laporan/') !== false) ? 'active' : ''; ?>">
            <a href="<?= $base_url; ?>/laporan/index.php">
                <i class="fa-solid fa-chart-line menu-i"></i>
                <span class="menu-text">Analitik & Laporan</span>
            </a>
        </li>
        
        <p class="sidebar-heading">Sistem</p>
        <li>
            <a href="<?= $base_url; ?>/logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar dari aplikasi?')">
                <i class="fa-solid fa-right-from-bracket menu-i text-danger"></i>
                <span class="menu-text text-danger fw-bold">Logout</span>
            </a>
        </li>
    </ul>
</nav>

<div id="content" class="d-flex flex-column w-100">
    
    <nav class="navbar-custom d-flex align-items-center justify-content-between mb-4 px-3 py-2 bg-white shadow-sm">
        <div class="d-flex align-items-center">
            <button type="button" id="sidebarCollapse" class="btn btn-primary me-3">
                <i class="fa-solid fa-bars"></i>
            </button>
            
            <div class="input-group d-none d-md-flex align-items-center bg-light px-3 py-1 rounded-2" style="max-width: 240px; border: 1px solid #e2e8f0;">
                <i class="fa-solid fa-magnifying-glass text-muted me-2" style="font-size: 0.85rem;"></i>
                <input type="text" class="form-control bg-transparent border-0 p-0 text-dark small" placeholder="Search..." style="box-shadow: none; font-size: 0.85rem;">
            </div>
        </div>

        <div class="d-flex align-items-center gap-3 text-muted">
            <i class="fa-regular fa-bell fs-5 d-none d-sm-block" style="cursor: pointer;" title="Notifications"></i>
            <i class="fa-regular fa-comment fs-5 d-none d-sm-block" style="cursor: pointer;" title="Messages"></i>
            
            <div class="dropdown">
                <div class="d-flex align-items-center gap-2 ps-2" style="border-left: 1px solid #e2e8f0; cursor: pointer;" id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=40&q=80" class="rounded-circle" width="35" height="35" alt="Mini Avatar">
                    <span class="text-dark fw-semibold small d-none d-sm-inline">John Doe</span>
                    <i class="fa-solid fa-chevron-down small text-muted d-none d-sm-inline" style="font-size: 0.75rem;"></i>
                </div>
                <ul class="dropdown-menu dropdown-menu-end border-0 shadow-sm mt-2 rounded-3" aria-labelledby="dropdownUser">
                    <li><a class="dropdown-item small" href="#"><i class="fa-regular fa-user me-2"></i>Profil Saya</a></li>
                    <li><a class="dropdown-item small" href="#"><i class="fa-solid fa-gear me-2"></i>Pengaturan</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item small text-danger fw-semibold" href="<?= $base_url; ?>/logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar dari aplikasi?')">
                            <i class="fa-solid fa-right-from-bracket me-2"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <script>
        document.getElementById('sidebarCollapse').addEventListener('click', function () {
            document.getElementById('sidebar').classList.toggle('active');
        });
    </script>

    <div class="container-fluid px-2 px-md-4">