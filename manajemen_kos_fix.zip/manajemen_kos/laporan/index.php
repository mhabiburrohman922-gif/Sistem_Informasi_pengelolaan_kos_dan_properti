<?php
include '../config/koneksi.php';
include '../layout/header.php';
include '../layout/sidebar.php';
/** @var mysqli $koneksi */

// 1. AMBIL PARAMETER FILTER TANGGAL
$tgl_mulai   = $_GET['tgl_mulai'] ?? '';
$tgl_selesai = $_GET['tgl_selesai'] ?? '';

// 2. KONDISI FILTER SQL
$filter_perbaikan  = "";
$filter_pembayaran = "";
if (!empty($tgl_mulai) && !empty($tgl_selesai)) {
    $filter_perbaikan  = " AND tanggal_permintaan BETWEEN '$tgl_mulai' AND '$tgl_selesai'";
    $filter_pembayaran = " AND (tanggal_pembayaran BETWEEN '$tgl_mulai' AND '$tgl_selesai' OR tgl_bayar BETWEEN '$tgl_mulai' AND '$tgl_selesai' OR tanggal BETWEEN '$tgl_mulai' AND '$tgl_selesai')";
}

// =========================================================================
// BLOK AMAN: Menghitung statistik box atas
// =========================================================================

// A. Hitung Kamar
$total_kamar = 0; $kamar_terisi = 0;
try {
    $res = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM kamar");
    $total_kamar = mysqli_fetch_assoc($res)['total'] ?? 0;
    
    $res2 = mysqli_query($koneksi, "SELECT COUNT(DISTINCT id_kamar) as total FROM kontrak_sewa");
    $kamar_terisi = mysqli_fetch_assoc($res2)['total'] ?? 0;
} catch (Throwable $e) { /* Safe fallback */ }

// B. Hitung Omzet Keuangan
$total_masuk = 0;
try {
    $res = mysqli_query($koneksi, "SELECT SUM(jumlah_bayar) as total FROM pembayaran_sewa WHERE 1=1 $filter_pembayaran");
    $total_masuk = mysqli_fetch_assoc($res)['total'] ?? 0;
} catch (Throwable $e) {
    try {
        $res = mysqli_query($koneksi, "SELECT SUM(total_bayar) as total FROM pembayaran_sewa WHERE 1=1 $filter_pembayaran");
        $total_masuk = mysqli_fetch_assoc($res)['total'] ?? 0;
    } catch (Throwable $e2) { $total_masuk = 0; }
}

// C. Hitung Perbaikan
$total_perbaikan = 0; $perbaikan_selesai = 0;
try {
    $res = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM permintaan_perbaikan WHERE 1=1 $filter_perbaikan");
    $total_perbaikan = mysqli_fetch_assoc($res)['total'] ?? 0;

    $res2 = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM permintaan_perbaikan WHERE status_perbaikan = 'Selesai' $filter_perbaikan");
    $perbaikan_selesai = mysqli_fetch_assoc($res2)['total'] ?? 0;
} catch (Throwable $e) { /* Safe fallback */ }
?>

<style>
    @media print {
        .no-print, header, sidebar, .navbar, .btn, form, #sidebar-wrapper, .sidebar-wrapper, .nav-toggle {
            display: none !important;
        }
        body, .container-fluid, .main-content {
            background: #fff !important;
            color: #000 !important;
            padding: 0 !important;
            margin: 0 !important;
            width: 100% !important;
        }
        .card { border: none !important; box-shadow: none !important; }
        .table { width: 100% !important; border: 1px solid #000 !important; }
        .table th, .table td { border: 1px solid #000 !important; padding: 6px !important; color: #000 !important; }
        .d-print-block { display: block !important; }
    }
</style>

<div class="container-fluid px-2 px-md-3 mt-3">
    
    <div class="d-none d-print-block text-center mb-4" style="border-bottom: 3px double #000; padding-bottom: 10px;">
        <h2 class="fw-bold m-0">KOSCLOVER MANAGEMENT</h2>
        <p class="m-0 italic small">Laporan Finansial &amp; Manajemen Perbaikan Fasilitas Terpadu</p>
        <p class="m-0 small" style="font-size: 0.8rem;">Periode: <?= (!empty($tgl_mulai)) ? $tgl_mulai.' s/d '.$tgl_selesai : 'Semua Periode'; ?></p>
    </div>

    <div class="no-print d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between p-3 bg-white rounded-3 shadow-sm mb-4 gap-2">
        <div>
            <h4 class="fw-bold text-dark mb-1">
                <i class="fa-solid fa-chart-pie text-primary me-2"></i>Analitik &amp; Laporan Kos Terpadu
            </h4>
            <p class="text-muted small mb-0">Rekapitulasi total pemasukan finansial kos beserta log keluhan perbaikan.</p>
        </div>
        <div class="d-flex gap-2 align-self-stretch align-self-md-center">
            <button onclick="window.print();" class="btn btn-sm btn-danger fw-bold shadow-sm px-3">
                <i class="fa-solid fa-file-pdf me-1"></i> Cetak / Ekspor PDF
            </button>
        </div>
    </div>

    <div class="no-print card border-0 shadow-sm rounded-3 mb-4">
        <div class="card-body py-3">
            <form method="GET" action="" class="row g-2 align-items-end">
                <div class="col-12 col-sm-4 col-md-3">
                    <label class="form-label small fw-bold text-muted mb-1">Mulai Tanggal</label>
                    <input type="date" name="tgl_mulai" class="form-control form-control-sm" value="<?= $tgl_mulai; ?>">
                </div>
                <div class="col-12 col-sm-4 col-md-3">
                    <label class="form-label small fw-bold text-muted mb-1">Sampai Tanggal</label>
                    <input type="date" name="tgl_selesai" class="form-control form-control-sm" value="<?= $tgl_selesai; ?>">
                </div>
                <div class="col-12 col-sm-4 col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-sm btn-primary w-100 fw-semibold"><i class="fa-solid fa-filter me-1"></i>Filter</button>
                    <a href="index.php" class="btn btn-sm btn-light border w-100 text-secondary"><i class="fa-solid fa-rotate-left"></i> Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-12 col-sm-4">
            <div class="card border-0 shadow-sm rounded-3 bg-success text-white p-2">
                <div class="card-body">
                    <h6 class="text-white-50 small fw-bold mb-1">TOTAL PENDAPATAN KOS</h6>
                    <h3 class="fw-bold mb-0">Rp <?= number_format($total_masuk, 0, ',', '.'); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-4">
            <div class="card border-0 shadow-sm rounded-3 bg-primary text-white p-2">
                <div class="card-body">
                    <h6 class="text-white-50 small fw-bold mb-1">OKUPANSI KAMAR KOS</h6>
                    <h3 class="fw-bold mb-0"><?= $kamar_terisi; ?> / <?= $total_kamar; ?> <span class="small fw-normal" style="font-size: 0.9rem">Terisi</span></h3>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-4">
            <div class="card border-0 shadow-sm rounded-3 bg-warning text-dark p-2">
                <div class="card-body">
                    <h6 class="text-dark-50 small fw-bold mb-1">LAPORAN PERBAIKAN</h6>
                    <h3 class="fw-bold mb-0"><?= $total_perbaikan; ?> <span class="small fw-normal text-muted" style="font-size: 0.9rem">Kasus (Selesai: <?= $perbaikan_selesai; ?>)</span></h3>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-3 mb-4">
        <div class="card-header bg-white py-3 border-0">
            <h6 class="m-0 fw-bold text-dark"><i class="fa-solid fa-file-invoice-dollar text-success me-2"></i>1. Log Transaksi Keuangan Masuk</h6>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="table-light text-uppercase text-secondary small">
                        <tr>
                            <th class="ps-4">No</th>
                            <th>Nama Penyewa</th>
                            <th>No Kamar</th>
                            <th>Metode</th>
                            <th>Tanggal Bayar</th>
                            <th class="pe-4 text-end">Jumlah Bayar</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php
                        $r_bayar = false;

                        // STRATEGI fallback 1: Menggunakan relasi langsung ke kontrak_sewa via id_kontrak
                        if (!$r_bayar) {
                            try {
                                $q = "SELECT pembayaran_sewa.*, penyewa.nama_penyewa, kamar.nomor_kamar 
                                      FROM pembayaran_sewa 
                                      LEFT JOIN kontrak_sewa ON pembayaran_sewa.id_kontrak = kontrak_sewa.id_kontrak
                                      LEFT JOIN penyewa ON kontrak_sewa.id_penyewa = penyewa.id_penyewa
                                      LEFT JOIN kamar ON kontrak_sewa.id_kamar = kamar.id_kamar
                                      WHERE 1=1 $filter_pembayaran ORDER BY 1 DESC";
                                $r_bayar = mysqli_query($koneksi, $q);
                            } catch (Throwable $e) {}
                        }

                        // STRATEGI fallback 2: Menggunakan relasi jembatan tabel tagihan_sewa
                        if (!$r_bayar) {
                            try {
                                $q = "SELECT pembayaran_sewa.*, penyewa.nama_penyewa, kamar.nomor_kamar 
                                      FROM pembayaran_sewa 
                                      LEFT JOIN tagihan_sewa ON pembayaran_sewa.id_tagihan = tagihan_sewa.id_tagihan
                                      LEFT JOIN kontrak_sewa ON tagihan_sewa.id_kontrak = kontrak_sewa.id_kontrak
                                      LEFT JOIN penyewa ON kontrak_sewa.id_penyewa = penyewa.id_penyewa
                                      LEFT JOIN kamar ON kontrak_sewa.id_kamar = kamar.id_kamar
                                      WHERE 1=1 $filter_pembayaran ORDER BY 1 DESC";
                                $r_bayar = mysqli_query($koneksi, $q);
                            } catch (Throwable $e) {}
                        }

                        // STRATEGI fallback 3: Menggunakan relasi langsung ke tabel penyewa jika ada id_penyewa langsung
                        if (!$r_bayar) {
                            try {
                                $q = "SELECT pembayaran_sewa.*, penyewa.nama_penyewa 
                                      FROM pembayaran_sewa 
                                      LEFT JOIN penyewa ON pembayaran_sewa.id_penyewa = penyewa.id_penyewa
                                      WHERE 1=1 $filter_pembayaran ORDER BY 1 DESC";
                                $r_bayar = mysqli_query($koneksi, $q);
                            } catch (Throwable $e) {}
                        }

                        // STRATEGI fallback 4: Tampilkan data murni dari pembayaran_sewa (Anti Eror!)
                        if (!$r_bayar) {
                            try {
                                $q = "SELECT * FROM pembayaran_sewa WHERE 1=1 $filter_pembayaran ORDER BY 1 DESC";
                                $r_bayar = mysqli_query($koneksi, $q);
                            } catch (Throwable $e) {}
                        }

                        // Render baris data ke HTML
                        if (!$r_bayar || mysqli_num_rows($r_bayar) == 0) {
                            echo "<tr><td colspan='6' class='text-center text-muted p-4'>Tidak ada riwayat transaksi keuangan masuk.</td></tr>";
                        } else {
                            $no = 1;
                            while ($b = mysqli_fetch_assoc($r_bayar)) {
                                $nominal = $b['jumlah_bayar'] ?? $b['total_bayar'] ?? 0;
                                $tgl_b    = $b['tanggal_pembayaran'] ?? $b['tgl_bayar'] ?? $b['tanggal'] ?? '-';
                                $nama_p   = $b['nama_penyewa'] ?? 'Umum / Tenant';
                                $no_kamar = isset($b['nomor_kamar']) ? 'Kamar ' . $b['nomor_kamar'] : '-';
                                $metode   = $b['metode_pembayaran'] ?? $b['metode'] ?? 'Cash/Transfer';
                                ?>
                                <tr>
                                    <td class="ps-4 text-muted fw-bold"><?= $no++; ?></td>
                                    <td class="fw-bold"><?= $nama_p; ?></td>
                                    <td><?= $no_kamar; ?></td>
                                    <td><?= $metode; ?></td>
                                    <td><?= ($tgl_b != '-') ? date('d M Y', strtotime($tgl_b)) : '-'; ?></td>
                                    <td class="pe-4 text-end fw-bold text-success">Rp <?= number_format($nominal, 0, ',', '.'); ?></td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-3 mb-5">
        <div class="card-header bg-white py-3 border-0">
            <h6 class="m-0 fw-bold text-dark"><i class="fa-solid fa-tools text-warning me-2"></i>2. Log Laporan Perbaikan &amp; Keluhan Kamar</h6>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="table-light text-uppercase text-secondary small">
                        <tr>
                            <th class="ps-4">No</th>
                            <th>No Kamar</th>
                            <th>Deskripsi Masalah</th>
                            <th>Tanggal Lapor</th>
                            <th class="pe-4 text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php
                        try {
                            $q_perbaikan = "SELECT permintaan_perbaikan.*, kamar.nomor_kamar 
                                            FROM permintaan_perbaikan
                                            JOIN kamar ON permintaan_perbaikan.id_kamar = kamar.id_kamar
                                            WHERE 1=1 $filter_perbaikan ORDER BY permintaan_perbaikan.id_perbaikan DESC";
                            $r_perbaikan = mysqli_query($koneksi, $q_perbaikan);

                            if (!$r_perbaikan || mysqli_num_rows($r_perbaikan) == 0) {
                                echo "<tr><td colspan='5' class='text-center text-muted p-4'>Tidak ada data pengaduan kerusakan fasilitas.</td></tr>";
                            } else {
                                $no_p = 1;
                                while ($p = mysqli_fetch_assoc($r_perbaikan)) {
                                    $st = $p['status_perbaikan'];
                                    $bg_badge = ($st == 'Selesai') ? 'bg-success' : (($st == 'Proses') ? 'bg-primary' : 'bg-warning text-dark');
                                    ?>
                                    <tr>
                                        <td class="ps-4 text-muted fw-bold"><?= $no_p++; ?></td>
                                        <td class="fw-bold">Kamar <?= $p['nomor_kamar']; ?></td>
                                        <td class="text-wrap"><?= $p['deskripsi']; ?></td>
                                        <td><?= date('d M Y', strtotime($p['tanggal_permintaan'])); ?></td>
                                        <td class="pe-4 text-center">
                                            <span class="badge <?= $bg_badge; ?> text-uppercase fw-bold p-1 px-2" style="font-size: 0.75rem;">
                                                <?= $st; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                        } catch (Throwable $e) {
                            echo "<tr><td colspan='5' class='text-center text-danger p-4'>Gagal memuat log perbaikan.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<?php include '../layout/footer.php'; ?>