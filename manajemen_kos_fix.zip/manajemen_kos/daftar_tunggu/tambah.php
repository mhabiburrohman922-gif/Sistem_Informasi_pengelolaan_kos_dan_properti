<?php
// 1. Paksa PHP untuk menampilkan error sintaks/fatal di layar browser
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2. Hubungkan koneksi database
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// 3. Proses jika tombol simpan ditekan
if (isset($_POST['simpan'])) {
    $nama_peminat   = mysqli_real_escape_string($koneksi, $_POST['nama_peminat']);
    $kontak         = mysqli_real_escape_string($koneksi, $_POST['kontak']);
    $id_tipe_kamar  = mysqli_real_escape_string($koneksi, $_POST['id_tipe_kamar']);
    $tanggal_daftar = mysqli_real_escape_string($koneksi, $_POST['tanggal_daftar']);
    $status_tunggu  = mysqli_real_escape_string($koneksi, $_POST['status_tunggu']); // FIX: Kembali ke status_tunggu

    // FIX: Menggunakan kolom 'status_tunggu' sesuai struktur tabel databasemu
    $query = "INSERT INTO daftar_tunggu_kamar (nama_peminat, kontak, id_tipe_kamar, tanggal_daftar, status_tunggu) 
              VALUES ('$nama_peminat', '$kontak', '$id_tipe_kamar', '$tanggal_daftar', '$status_tunggu')";
              
    $simpan = mysqli_query($koneksi, $query);
    
    if ($simpan) {
        echo "<script>alert('Peminat berhasil didaftarkan!'); window.location.href='index.php';</script>";
        exit;
    } else {
        die("Gagal SQL: " . mysqli_error($koneksi));
    }
}

// 4. Ambil data tipe kamar untuk dropdown select
$tipe_res = mysqli_query($koneksi, "SELECT * FROM tipe_kamar");

// 5. Load layout template
include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <div class="row mb-4">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <div>
                <h3 class="fw-bold text-dark mb-1">Tambah Peminat Baru</h3>
                <p class="text-muted small mb-0">Input data calon penghuni ke dalam daftar tunggu kamar.</p>
            </div>
            <a href="index.php" class="btn btn-light border px-4 py-2 rounded-3 shadow-sm">
                <i class="fa-solid fa-arrow-left me-2"></i>Kembali
            </a>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-4">
            <form action="" method="POST">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-secondary">NAMA CALON PEMINAT</label>
                        <input type="text" name="nama_peminat" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" placeholder="Contoh: Agung Tri" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-secondary">KONTAK (NO. HP / EMAIL)</label>
                        <input type="text" name="kontak" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" placeholder="Contoh: 081234567xxx" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary">PILIHAN TIPE KAMAR</label>
                        <select name="id_tipe_kamar" class="form-select form-select-lg bg-light border-0 rounded-3 fs-6" required>
                            <option value="">-- Pilih Kategori Kamar --</option>
                            <?php 
                            if ($tipe_res && mysqli_num_rows($tipe_res) > 0) {
                                while($t = mysqli_fetch_assoc($tipe_res)) {
                                    echo "<option value='".$t['id_tipe']."'>".$t['nama_tipe']."</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary">TANGGAL DAFTAR</label>
                        <input type="date" name="tanggal_daftar" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" value="<?= date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary">STATUS</label>
                        <!-- FIX: Name attribute disesuaikan menjadi status_tunggu -->
                        <select name="status_tunggu" class="form-select form-select-lg bg-light border-0 rounded-3 fs-6" required>
                            <option value="Menunggu">Menunggu</option>
                            <option value="Dihubungi">Dihubungi</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-end gap-2 mt-4">
                    <a href="index.php" class="btn btn-light px-4 py-2 rounded-3">Batal</a>
                    <button type="submit" name="simpan" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">Simpan Peminat</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>