<?php
include '../config/koneksi.php';
include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <div class="d-flex justify-content-between mb-4 align-items-center">
        <div>
            <h3 class="fw-bold text-dark mb-1">Daftar Tunggu Kamar</h3>
            <p class="text-muted small mb-0">Kelola data peminat kos yang menunggu kamar kosong tersedia.</p>
        </div>
        <a href="tambah.php" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">
            <i class="fa-solid fa-plus me-2"></i>Tambah Peminat
        </a>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="min-width: 800px;">
                    <thead class="bg-light text-secondary text-uppercase font-monospace fs-7">
                        <tr>
                            <th class="ps-4 py-3" style="width: 5%;">No</th>
                            <th class="py-3" style="width: 25%;">Nama Peminat</th>
                            <th class="py-3" style="width: 25%;">Kontak (No. HP/Email)</th>
                            <th class="py-3" style="width: 15%;">Tanggal Daftar</th>
                            <th class="py-3" style="width: 15%;">Status</th>
                            <th class="pe-4 py-3 text-end" style="width: 15%;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php
                        /** @var mysqli $koneksi */
                        $no = 1;
                        $query = "SELECT * FROM daftar_tunggu_kamar ORDER BY id_daftar_tunggu DESC";
                        $res = mysqli_query($koneksi, $query);
                        
                        while ($row = mysqli_fetch_assoc($res)) {
                            // Cek warna badge status_tunggu
                            if ($row['status_tunggu'] == 'Dihubungi') {
                                $badge = '<span class="badge bg-success bg-opacity-10 text-success px-3 py-2 rounded-pill"><i class="fa-solid fa-phone me-1"></i> Dihubungi</span>';
                            } else {
                                $badge = '<span class="badge bg-warning bg-opacity-10 text-warning px-3 py-2 rounded-pill"><i class="fa-solid fa-clock me-1"></i> Menunggu</span>';
                            }
                        ?>
                        <tr>
                            <td class="ps-4 fw-medium text-secondary"><?= $no++; ?></td>
                            <td class="fw-bold text-dark"><?= htmlspecialchars($row['nama_peminat']); ?></td>
                            <td class="text-secondary"><?= htmlspecialchars($row['kontak']); ?></td>
                            <td class="text-secondary"><?= date('d M Y', strtotime($row['tanggal_daftar'])); ?></td>
                            <td><?= $badge; ?></td>
                            <td class="pe-4 text-end">
                                <div class="d-inline-flex gap-1">
                                    <?php if ($row['status_tunggu'] == 'Menunggu') { ?>
                                        <a href="ubah_status.php?id=<?= $row['id_daftar_tunggu']; ?>" class="btn btn-sm btn-outline-success rounded-3" title="Tandai Sudah Dihubungi">
                                            <i class="fa-solid fa-check"></i>
                                        </a>
                                    <?php } ?>

                                    <a href="../penyewa/tambah.php?from_waiting=<?= $row['id_daftar_tunggu']; ?>&nama=<?= urlencode($row['nama_peminat']); ?>&kontak=<?= urlencode($row['kontak']); ?>" class="btn btn-sm btn-success rounded-3 text-white px-2">
                                        <i class="fa-solid fa-user-plus me-1"></i> Proses
                                    </a>

                                    <a href="hapus.php?id=<?= $row['id_daftar_tunggu']; ?>" class="btn btn-sm btn-outline-danger rounded-3" onclick="return confirm('Hapus peminat dari daftar tunggu?')">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>