<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// Cek apakah ada ID yang dikirim
if (isset($_GET['id']) && !empty($_GET['id'])) {
    // Amankan input
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);
    
    // Gunakan nama tabel dan kolom yang sesuai dengan struktur database
    $query = "DELETE FROM daftar_tunggu_kamar WHERE id_daftar_tunggu = '$id'";
    $hapus = mysqli_query($koneksi, $query);
    
    if ($hapus) {
        echo "<script>
                alert('Data antrean berhasil dihapus!'); 
                window.location.href = 'index.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus data: " . mysqli_error($koneksi) . "'); 
                window.location.href = 'index.php';
              </script>";
    }
} else {
    // Jika tidak ada ID, kembali ke index
    header('Location: index.php');
    exit;
}
?>