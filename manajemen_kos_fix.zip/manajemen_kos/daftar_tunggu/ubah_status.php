<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);
    
    // Update status dadi Dihubungi
    $query = "UPDATE daftar_tunggu_kamar SET status_tunggu = 'Dihubungi' WHERE id_daftar_tunggu = '$id'";
    $update = mysqli_query($koneksi, $query);
    
    if ($update) {
        header("Location: index.php");
        exit;
    } else {
        echo "Gagal mengubah status: " . mysqli_error($koneksi);
    }
} else {
    header("Location: index.php");
    exit;
}
?>