<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('ID Antrean tidak ditemukan!'); window.location.href='index.php';</script>";
    exit;
}

$id_tunggu = mysqli_real_escape_string($koneksi, $_GET['id']);

// Ambil data antrean yang lama
$query = "SELECT * FROM daftar_tunggu WHERE id_tunggu = '$id_tunggu'";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

// Ambil opsi tipe kamar
$tipe_res = mysqli_query($koneksi, "SELECT * FROM tipe_kamar");

if (isset($_POST['update'])) {
    $nama_calon     = mysqli_real_escape_string($koneksi, $_POST['nama_calon']);
    $no_telp        = mysqli_real_escape_string($koneksi, $_POST['no_telp']);
    $id_tipe        = mysqli_real_escape_string($koneksi, $_POST['id_tipe']);
    $tanggal_daftar = mysqli_real_escape_string($koneksi, $_POST['tanggal_daftar']);
    $status_tunggu  = mysqli_real_escape_string($koneksi, $_POST['status_tunggu']);

    $query_update = "UPDATE daftar_tunggu SET 
                        nama_calon = '$nama_calon', 
                        no_telp = '$no_telp', 
                        id_tipe = '$id_tipe', 
                        tanggal_daftar = '$tanggal_daftar', 
                        status_tunggu = '$status_tunggu' 
                     WHERE id_tunggu = '$id_tunggu'";

    $update = mysqli_query($koneksi, $query_update);

    if ($update) {
        echo "<script>alert('Data antrean berhasil diupdate!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Gagal mengupdate data: " . mysqli_error($koneksi) . "');</script>";
    }
}

include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <div class="row mb-4">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <div>
                <h3 class="fw-bold text-dark mb-1">Edit Antrean Daftar Tunggu</h3>
                <p class="text-muted small mb-0">Perbarui data atau status antrean masuk kamar kos.</p>
            </div>
            <a href="index.php" class="btn btn-light border px-4 py-2 rounded-3 shadow-sm">
                <i class="fa-solid fa-arrow-left me-2"></i>Kembali
            </a>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-4">
            <form action="" method="POST">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-secondary">NAMA CALON PENYEWA</label>
                        <input type="text" name="nama_calon" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" value="<?= htmlspecialchars($data['nama_calon']); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-secondary">NOMOR TELEPON / WA</label>
                        <input type="text" name="no_telp" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" value="<?= htmlspecialchars($data['no_telp']); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary">PILIHAN TIPE KAMAR</label>
                        <select name="id_tipe" class="form-select form-select-lg bg-light border-0 rounded-3 fs-6" required>
                            <?php while($t = mysqli_fetch_assoc($tipe_res)): ?>
                                <option value="<?= $t['id_tipe']; ?>" <?= $data['id_tipe'] == $t['id_tipe'] ? 'selected' : ''; ?>>
                                    <?= $t['nama_tipe']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary">TANGGAL DAFTAR ANTREAN</label>
                        <input type="date" name="tanggal_daftar" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" value="<?= $data['tanggal_daftar']; ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary">STATUS ANTREAN</label>
                        <select name="status_tunggu" class="form-select form-select-lg bg-light border-0 rounded-3 fs-6" required>
                            <option value="Menunggu" <?= $data['status_tunggu'] == 'Menunggu' ? 'selected' : ''; ?>>Menunggu Kamar Kosong</option>
                            <option value="Dapat Kamar" <?= $data['status_tunggu'] == 'Dapat Kamar' ? 'selected' : ''; ?>>Dapat Kamar</option>
                            <option value="Batal" <?= $data['status_tunggu'] == 'Batal' ? 'selected' : ''; ?>>Batal / Cancel</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-end gap-2 mt-4">
                    <a href="index.php" class="btn btn-light px-4 py-2 rounded-3">Batal</a>
                    <button type="submit" name="update" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>