<?php
include '../config/koneksi.php';
include '../layout/header.php';
include '../layout/sidebar.php';

// Fitur Proses Hapus Data
if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus') {
    $id = $_GET['id'];
    $hapus = mysqli_query($koneksi, "DELETE FROM tipe_kamar WHERE id_tipe = '$id'");
    if ($hapus) {
        echo "<script>alert('Data berhasil dihapus!'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus! Data mungkin sedang digunakan di tabel kamar.'); window.location='index.php';</script>";
    }
}

// Fitur Ambil Data untuk Diedit
$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM tipe_kamar WHERE id_tipe = '$id'");
$row = mysqli_fetch_array($data);

// Fitur Proses Update Data
if (isset($_POST['update'])) {
    $nama_tipe = $_POST['nama_tipe'];
    $harga     = $_POST['harga'];
    $deskripsi = $_POST['deskripsi'];

    $update = mysqli_query($koneksi, "UPDATE tipe_kamar SET nama_tipe='$nama_tipe', harga='$harga', deskripsi='$deskripsi' WHERE id_tipe='$id'");
    if ($update) {
        echo "<script>alert('Data berhasil diubah!'); window.location='index.php';</script>";
    }
}
?>

<div class="content">
    <h2>Edit Tipe Kamar</h2>
    <form action="" method="POST">
        <div class="form-group">
            <label>Nama Tipe Kamar</label>
            <input type="text" name="nama_tipe" value="<?= $row['nama_tipe']; ?>" required class="form-control">
        </div>
        <div class="form-group">
            <label>Harga per Bulan</label>
            <input type="number" name="harga" value="<?= $row['harga']; ?>" required class="form-control">
        </div>
        <div class="form-group">
            <label>Deskripsi / Fasilitas</label>
            <textarea name="deskripsi" class="form-control"><?= $row['deskripsi']; ?></textarea>
        </div>
        <button type="submit" name="update" class="btn btn-success">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../layout/footer.php'; ?>