<?php 
// 1. Hidupkan pelaporan error untuk melacak jika ada path yang salah atau query bermasalah
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2. Hubungkan ke database TERLEBIH DAHULU sebelum memanggil layout utama
include '../config/koneksi.php'; 

// 3. Load file header dan UI sidebar dari folder layout
include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold text-dark mb-1">Daftar Tipe Kamar</h3>
                    <p class="text-muted small mb-0">Kelola kategori, fasilitas utama, dan harga sewa dasar kamar kos.</p>
                </div>
                <a href="tambah.php" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">
                    <i class="fa-solid fa-plus me-2"></i>Tambah Tipe Kamar
                </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light text-secondary">
                                <tr>
                                    <th width="60" class="text-center">No</th>
                                    <th>Nama Tipe</th>
                                    <th>Fasilitas / Deskripsi</th>
                                    <th>Harga Bulanan</th>
                                    <th width="150" class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                /** @var mysqli $koneksi */
                                // Fetch data dari database secara dinamis
                                $sql = "SELECT * FROM tipe_kamar";
                                $result = mysqli_query($koneksi, $sql);
                                $no = 1;

                                if ($result && mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        // Ambil data sesuai dengan kolom database milikmu
                                        $id_tipe   = $row['id_tipe'];
                                        $nama_tipe = $row['nama_tipe'];
                                      // UBAH BARIS INI:
$deskripsi = !empty($row['fasilitas']) ? $row['fasilitas'] : 'Tidak ada deskripsi fasilitas.';
                                        $tarif     = $row['tarif_bulanan'];
                                        ?>
                                        <tr>
                                            <td class="text-center fw-semibold"><?= $no; ?></td>
                                            <td>
                                                <span class="fw-bold text-dark"><?= htmlspecialchars($nama_tipe); ?></span>
                                            </td>
                                            <td>
                                                <span class="badge bg-info-subtle text-info rounded-pill px-2.5 py-1.5 small">
                                                    <i class="fa-solid fa-circle-info me-1"></i> <?= htmlspecialchars($deskripsi); ?>
                                                </span>
                                            </td>
                                            <td class="fw-bold text-success">Rp <?= number_format($tarif, 0, ',', '.'); ?></td>
                                            <td class="text-center">
                                                <div class="btn-group gap-1">
                                                    <a href="edit.php?id=<?= $id_tipe; ?>" class="btn btn-sm btn-outline-warning rounded-2" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </a>
                                                    <a href="hapus.php?id=<?= $id_tipe; ?>" class="btn btn-sm btn-outline-danger rounded-2" onclick="return confirm('Apakah Anda yakin ingin menghapus tipe kamar ini?')" title="Hapus">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                        $no++;
                                    }
                                } else {
                                    // Tampilan jika data di database masih kosong belor
                                    echo "<tr><td colspan='5' class='text-center py-4 text-muted'>Belum ada data tipe kamar tersedia. Silakan tambahkan data baru.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
// 4. Menutup penampung container halaman dan load script JavaScript
include '../layout/footer.php'; 
?>