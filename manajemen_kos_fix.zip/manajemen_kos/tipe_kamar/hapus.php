<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */
// Pastikan ada parameter ID yang dikirim
if (isset($_GET['id'])) {
    $id_tipe = $_GET['id'];

    // Query hapus data berdasarkan id_tipe
    $query = "DELETE FROM tipe_kamar WHERE id_tipe = '$id_tipe'";
    $exec = mysqli_query($koneksi, $query);

    if ($exec) {
        echo "<script>
                alert('Data tipe kamar berhasil dihapus!');
                window.location.href = 'index.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus data! Data ini kemungkinan masih terikat dengan tabel kamar.');
                window.location.href = 'index.php';
              </script>";
    }
} else {
    // Kalau langsung akses file tanpa ID, balikin ke index
    header('Location: index.php');
}
?>