<?php 
// 1. Hidupkan deteksi error agar jika query gagal, teks errornya langsung muncul (tidak blank putih)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2. Hubungkan ke database TERLEBIH DAHULU
include '../config/koneksi.php'; 
/** @var mysqli $koneksi */
// 3. Proses Simpan Data (Akan dieksekusi saat tombol 'Simpan Tipe Kamar' diklik)
// 3. Proses Simpan Data (Akan dieksekusi saat tombol 'Simpan Tipe Kamar' diklik)
if (isset($_POST['simpan'])) {
    $nama_tipe     = mysqli_real_escape_string($koneksi, $_POST['nama_tipe']);
    $tarif_bulanan = mysqli_real_escape_string($koneksi, $_POST['tarif_bulanan']);
    $deskripsi     = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);

    // QUERY DIPERBAIKI: Mengubah nama kolom 'deskripsi' menjadi 'fasilitas' agar cocok dengan struktur databasemu
    $query  = "INSERT INTO tipe_kamar (nama_tipe, tarif_bulanan, fasilitas) VALUES ('$nama_tipe', '$tarif_bulanan', '$deskripsi')";
    $simpan = mysqli_query($koneksi, $query);

    if ($simpan) {
        echo "<script>
                alert('Tipe kamar berhasil ditambahkan!');
                window.location='index.php';
              </script>";
        exit;
    } else {
        die("Gagal menyimpan data ke database! Error: " . mysqli_error($koneksi));
    }
}
// 4. Baru load file UI header dan sidebar setelah logika PHP di atas aman
include '../layout/header.php';
include '../layout/sidebar.php';
?>

<style>
    .custom-label {
        font-size: 0.85rem;
        font-weight: 700;
        color: #2c3e50;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
    }
    .custom-input {
        background-color: #f8f9fa !important;
        border: 1px solid #e9ecef !important;
        padding: 12px 16px;
        border-radius: 8px;
        color: #495057;
    }
    .custom-input:focus {
        background-color: #fff !important;
        border-color: #3b71ca !important;
        box-shadow: 0 0 0 0.25rem rgba(59, 113, 202, 0.1) !important;
    }
    .card-custom {
        border-radius: 16px;
        border: none;
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.02) !important;
    }
    .btn-simpan {
        background-color: #0d6efd;
        color: white;
        border-radius: 10px;
        padding: 10px 24px;
        font-weight: 600;
        border: none;
    }
    .btn-simpan:hover {
        background-color: #0b5ed7;
        color: white;
    }
    .btn-batal {
        background-color: #f8f9fa;
        color: #6c757d;
        border-radius: 10px;
        padding: 10px 24px;
        font-weight: 600;
        border: 1px solid #e9ecef;
    }
    .btn-batal:hover {
        background-color: #e2e6ea;
        color: #495057;
    }
</style>

<div class="container-fluid mb-5 px-4">
    <div class="d-flex justify-content-between mb-4 align-items-center">
        <h2 class="fw-bold" style="color: #1e293b;">Form Tambah Tipe Kamar Baru</h2>
        <a href="index.php" class="btn btn-light btn-sm text-muted px-3 py-2 border" style="border-radius: 8px;">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali
        </a>
    </div>

    <div class="card card-custom bg-white p-2">
        <div class="card-body p-4">
            <form action="" method="POST">
                
                <div class="row mb-4">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <label class="form-label custom-label">Nama Tipe Kamar</label>
                        <input type="text" name="nama_tipe" placeholder="Contoh: Deluxe Class" required class="form-control custom-input">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label custom-label">Tarif Kategori Bulanan (Rp)</label>
                        <input type="number" name="tarif_bulanan" placeholder="Contoh: 1500000" required class="form-control custom-input">
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-12">
                        <label class="form-label custom-label">Deskripsi / Detail Keterangan Fasilitas</label>
                        <textarea name="deskripsi" rows="4" placeholder="Tambahkan spesifikasi atau daftar fasilitas tipe kamar di sini..." class="form-control custom-input"></textarea>
                    </div>
                </div>
                
                <div class="d-flex justify-content-end gap-2 mt-4">
                    <a href="index.php" class="btn btn-batal">Batal</a>
                    <button type="submit" name="simpan" class="btn btn-simpan">Simpan Tipe Kamar</button>
                </div>

            </form>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>