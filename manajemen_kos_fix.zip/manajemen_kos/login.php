<?php
// 1. Aktifkan penampil error untuk mendeteksi penyebab HTTP 500
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 2. Mulai sesi
session_start();

// 3. Pastikan file koneksi ada
$file_koneksi = 'config/koneksi.php';
if (!file_exists($file_koneksi)) {
    die("Error: File koneksi tidak ditemukan di path: " . realpath($file_koneksi));
}
require_once $file_koneksi;

// Jika sesi sudah ada, lempar ke index
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header("Location: index.php");
    exit;
}

$error = false;

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, trim($_POST['username']));
    $password = trim($_POST['password']);

    $query = mysqli_query($koneksi, "SELECT * FROM user WHERE username = '$username'");
    
    if ($query && mysqli_num_rows($query) > 0) {
        $row = mysqli_fetch_assoc($query);
        
        // Cek password
        if ($password === $row['password'] || md5($password) === $row['password'] || password_verify($password, $row['password'])) {
            $_SESSION['login'] = true;
            $_SESSION['username'] = $row['username'];
            header("Location: index.php");
            exit;
        } else {
            $error = true;
        }
    } else {
        $error = true;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Account - KOSCLOVER</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f8fafc;
            min-height: 100vh;
        }
        .login-wrapper {
            min-height: 100vh;
        }
        .login-banner {
            background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px;
            color: white;
        }
        .login-banner::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background-image: radial-gradient(circle at 20% 30%, rgba(255,255,255,0.1) 0%, transparent 20%),
                              radial-gradient(circle at 75% 70%, rgba(255,255,255,0.15) 0%, transparent 25%);
            pointer-events: none;
        }
        .banner-title {
            font-size: 2.8rem;
            font-weight: 800;
            letter-spacing: 1px;
            text-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .login-form-container {
            display: flex;
            align-items: center;
            justify-content: center;
            background: #ffffff;
            padding: 40px;
        }
        .form-box {
            width: 100%;
            max-width: 380px;
        }
        .form-control {
            border-radius: 12px;
            padding: 12px 16px;
            border: 1px solid #e2e8f0;
            font-size: 0.95rem;
            background-color: #f8fafc;
            transition: all 0.2s ease;
        }
        .form-control:focus {
            background-color: #fff;
            border-color: #3b82f6;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.15);
        }
        .btn-login {
            background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
            border: none;
            border-radius: 12px;
            padding: 13px;
            font-weight: 600;
            font-size: 1rem;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(37, 99, 234, 0.3);
        }
        .alert-custom {
            border-radius: 12px;
            font-size: 0.9rem;
            border: none;
        }
    </style>
</head>
<body>

<div class="container-fluid p-0">
    <div class="row g-0 login-wrapper">
        
        <div class="col-lg-6 d-none d-lg-flex login-banner text-center">
            <div class="grid-overlay"></div>
            <div class="position-relative" style="z-index: 2;">
                <div class="display-1 text-white-50 mb-3"><i class="fa-solid fa-house-chimney-window"></i></div>
                <h1 class="banner-title mb-2">WELCOME BACK</h1>
                <p class="text-white-50 fs-5 fw-light">Sistem Terpadu Manajemen Operasional &amp; Finansial Kos Clover</p>
            </div>
        </div>

        <div class="col-12 col-lg-6 login-form-container">
            <div class="form-box">
                
                <div class="mb-4 text-center text-lg-start">
                    <h2 class="fw-bold text-dark mb-1">Login Account</h2>
                    <p class="text-muted small">Masukkan akun Anda untuk mengakses dashboard manajemen kos.</p>
                </div>

                <?php if ($error) : ?>
                    <div class="alert alert-danger alert-custom p-3 mb-4 d-flex align-items-center shadow-sm" role="alert">
                        <i class="fa-solid fa-circle-exclamation fs-5 me-3"></i>
                        <div>Username atau Password salah! Periksa kembali data Anda.</div>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label small fw-bold text-secondary mb-1">Username</label>
                        <input type="text" name="username" id="username" class="form-control" placeholder="Contoh: Dimas / Triawan" required autocomplete="off" autofocus>
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label small fw-bold text-secondary mb-1">Password</label>
                        <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan kata sandi anda" required>
                    </div>

                    <button type="submit" name="login" class="btn btn-primary btn-login w-100 text-uppercase text-white shadow-sm">
                        Masuk Ke Dashboard <i class="fa-solid fa-arrow-right-to-bracket ms-2"></i>
                    </button>
                </form>

                <div class="mt-5 text-center text-muted small" style="font-size: 0.8rem;">
                    &copy; 2026 <span class="fw-semibold">KOSCLOVER</span>. All Rights Reserved.
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>