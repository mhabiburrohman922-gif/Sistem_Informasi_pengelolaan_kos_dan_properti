<?php
session_start();
// 1. Koneksi ke Database
require_once '../config/koneksi.php';

// 2. Tangkap data dari form login.php
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    // 3. Query ke tabel user/admin (sesuaikan nama tabelmu, contoh di sini: 'user')
    $query = mysqli_query($koneksi, "SELECT * FROM user WHERE username='$username' AND password='$password'");
    $cek = mysqli_num_rows($query);

    if ($cek > 0) {
        $data = mysqli_fetch_assoc($query);
        
        // Buat session login
        $_SESSION['username'] = $username;
        $_SESSION['status'] = "login";
        $_SESSION['role'] = $data['role']; // Jika ada pembagian hak akses

        // Alihkan ke halaman dashboard utama
        header("location:index.php");
    } else {
        // Jika gagal, kembali ke login dan beri pesan error
        header("location:login.php?pesan=gagal");
    }
}
?>