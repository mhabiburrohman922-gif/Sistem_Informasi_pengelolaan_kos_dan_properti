<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */
// Pastikan ada parameter ID penyewa yang dikirim
if (isset($_GET['id'])) {
    $id_penyewa = $_GET['id'];

    // Query hapus data berdasarkan id_penyewa
    $query = "DELETE FROM penyewa WHERE id_penyewa = '$id_penyewa'";
    $exec = mysqli_query($koneksi, $query);

    if ($exec) {
        echo "<script>
                alert('Data penyewa berhasil dihapus!');
                window.location.href = 'index.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus data! Penyewa ini kemungkinan masih terikat dengan kontrak sewa yang aktif.');
                window.location.href = 'index.php';
              </script>";
    }
} else {
    // Kalau langsung akses file tanpa ID, balikin ke index
    header('Location: index.php');
}
?>