<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/** @var mysqli $koneksi */
include_once '../config/koneksi.php'; 
include_once '../layout/header.php';
include_once '../layout/sidebar.php';

// --- LOGIKA MENANGKAP DATA OTOMATIS DARI DAFTAR TUNGGU ---
$nama_otomatis  = isset($_GET['nama']) ? htmlspecialchars($_GET['nama']) : '';
$kontak_otomatis = isset($_GET['kontak']) ? htmlspecialchars($_GET['kontak']) : '';
$id_waiting      = isset($_GET['from_waiting']) ? htmlspecialchars($_GET['from_waiting']) : '';

// Karena data di kolom 'kontak' daftar_tunggu bisa berisi email atau No. HP, 
// kita lakukan deteksi sederhana agar data terisi di kolom input yang pas.
$email_otomatis = '';
$telp_otomatis  = '';

if (!empty($kontak_otomatis)) {
    if (filter_var($kontak_otomatis, FILTER_VALIDATE_EMAIL)) {
        $email_otomatis = $kontak_otomatis;
    } else {
        $telp_otomatis = $kontak_otomatis;
    }
}

if (isset($_POST['simpan'])) {
    $nama_penyewa   = mysqli_real_escape_string($koneksi, $_POST['nama_penyewa']);
    $email          = mysqli_real_escape_string($koneksi, $_POST['email']);
    $no_telp        = mysqli_real_escape_string($koneksi, $_POST['no_telp']);
    $no_ktp         = mysqli_real_escape_string($koneksi, $_POST['no_ktp']);
    $id_df_tunggu   = mysqli_real_escape_string($koneksi, $_POST['id_daftar_tunggu']);

    // 1. Jalankan query insert data ke tabel penyewa
    $query  = "INSERT INTO penyewa (nama_penyewa, no_ktp, no_telp, email) 
               VALUES ('$nama_penyewa', '$no_ktp', '$no_telp', '$email')";
    $simpan = mysqli_query($koneksi, $query);

    if ($simpan) {
        // 2. JIKA pendaftaran ini berasal dari tombol proses daftar tunggu,
        // hapus datanya dari tabel daftar_tunggu_kamar secara otomatis
        if (!empty($id_df_tunggu)) {
            mysqli_query($koneksi, "DELETE FROM daftar_tunggu_kamar WHERE id_daftar_tunggu = '$id_df_tunggu'");
        }

        echo "<script>
                alert('Data penyewa berhasil ditambahkan dan antrean daftar tunggu diperbarui!');
                window.location='index.php';
              </script>";
        exit;
    } else {
        echo "<script>
                alert('Gagal menambahkan data penyewa! Error: " . mysqli_error($koneksi) . "');
              </script>";
    }
}
?>

<style>
    .custom-label {
        font-size: 0.85rem;
        font-weight: 700;
        color: #2c3e50;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
    }
    .custom-input {
        background-color: #f8f9fa !important;
        border: 1px solid #e9ecef !important;
        padding: 12px 16px;
        border-radius: 8px;
        color: #495057;
    }
    .custom-input:focus {
        background-color: #fff !important;
        border-color: #3b71ca !important;
        box-shadow: 0 0 0 0.25rem rgba(59, 113, 202, 0.1) !important;
    }
    .card-custom {
        border-radius: 16px;
        border: none;
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.02) !important;
    }
    .btn-simpan {
        background-color: #0d6efd;
        color: white;
        border-radius: 10px;
        padding: 10px 24px;
        font-weight: 600;
        border: none;
    }
    .btn-simpan:hover {
        background-color: #0b5ed7;
        color: white;
    }
    .btn-batal {
        background-color: #f8f9fa;
        color: #6c757d;
        border-radius: 10px;
        padding: 10px 24px;
        font-weight: 600;
        border: 1px solid #e9ecef;
    }
    .btn-batal:hover {
        background-color: #e2e6ea;
        color: #495057;
    }
</style>

<div class="container-fluid mb-5 px-4">
    <div class="d-flex justify-content-between mb-4 align-items-center">
        <h2 class="fw-bold" style="color: #1e293b;">Form Tambah Penyewa Baru</h2>
        <a href="index.php" class="btn btn-light btn-sm text-muted px-3 py-2 border" style="border-radius: 8px;">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali
        </a>
    </div>

    <div class="card card-custom bg-white p-2">
        <div class="card-body p-4">
            <form action="" method="POST">
                
                <!-- Input hidden untuk membawa ID Daftar Tunggu -->
                <input type="hidden" name="id_daftar_tunggu" value="<?= $id_waiting; ?>">
                
                <div class="row mb-4">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <label class="form-label custom-label">Nama Lengkap</label>
                        <input type="text" name="nama_penyewa" value="<?= $nama_otomatis; ?>" placeholder="Masukkan nama lengkap" required class="form-control custom-input">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label custom-label">Alamat Email</label>
                        <input type="email" name="email" value="<?= $email_otomatis; ?>" placeholder="Contoh: nama@email.com" class="form-control custom-input">
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <label class="form-label custom-label">Nomor WhatsApp / Telepon</label>
                        <input type="text" name="no_telp" value="<?= $telp_otomatis; ?>" placeholder="Contoh: 081234567xxx" class="form-control custom-input">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label custom-label">Nomor KTP / Identitas</label>
                        <!-- Biarkan kosong agar admin tinggal mengetikkan No. KTP asli calon penghuni -->
                        <input type="text" name="no_ktp" placeholder="Masukkan 16 digit No. KTP" required class="form-control custom-input">
                    </div>
                </div>
                
                <div class="d-flex justify-content-end gap-2 mt-5">
                    <a href="index.php" class="btn btn-batal">Batal</a>
                    <button type="submit" name="simpan" class="btn btn-simpan">Simpan Data</button>
                </div>

            </form>
        </div>
    </div>
</div>

<?php include_once '../layout/footer.php'; ?>