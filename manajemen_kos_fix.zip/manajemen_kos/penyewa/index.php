<?php
include '../layout/header.php';
include '../layout/sidebar.php';
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// Ambil data dari tabel penyewa
$query = "SELECT * FROM penyewa ORDER BY id_penyewa DESC";
$result = mysqli_query($koneksi, $query);
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Data Penyewa</h3>
                <p class="text-muted small mb-0">Kelola informasi biodata seluruh penghuni kos.</p>
            </div>
            <a href="tambah.php" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">
                <i class="fa-solid fa-plus me-2"></i>Tambah Penyewa
            </a>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light text-secondary">
                            <tr>
                                <th width="60" class="text-center">No</th>
                                <th>Nama Lengkap</th>
                                <th>No. Telepon</th>
                                <th>Status</th>
                                <th width="150" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            // 1. Cek apakah ada data di dalam database
                            if (mysqli_num_rows($result) > 0) {
                                // 2. Lakukan perulangan while untuk memecah data array ke variabel $row
                                while ($row = mysqli_fetch_assoc($result)) {
                                    // Mengambil nomor telepon berdasarkan nama kolom database 'no_telp'
                                    $no_telp = !empty($row['no_telp']) ? $row['no_telp'] : '-';
                                    ?>
                                    <tr>
                                        <td class="text-center fw-semibold"><?= $no++; ?></td>
                                        <td><span class="fw-bold text-dark"><?= htmlspecialchars($row['nama_penyewa']); ?></span></td>
                                        <td><?= htmlspecialchars($no_telp); ?></td>
                                        <td>
                                            <span class="badge bg-success-subtle text-success rounded-pill px-2.5 py-1.5">Aktif</span>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group gap-1">
                                                <a href="edit.php?id=<?= $row['id_penyewa']; ?>" class="btn btn-sm btn-outline-warning rounded-2">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </a>
                                                <a href="hapus.php?id=<?= $row['id_penyewa']; ?>" class="btn btn-sm btn-outline-danger rounded-2" onclick="return confirm('Hapus data penyewa ini?')">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php 
                                } // baris penutup loop while
                            } else { 
                                ?>
                                <tr><td colspan="5" class="text-center py-4 text-muted">Belum ada data penyewa.</td></tr>
                                <?php 
                            } 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>