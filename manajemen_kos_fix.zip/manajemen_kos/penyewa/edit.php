<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// 1. Cek apakah ada ID yang dikirim lewat URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('ID Penyewa tidak ditemukan!'); window.location.href='index.php';</script>";
    exit;
}

$id_penyewa = mysqli_real_escape_string($koneksi, $_GET['id']);

// 2. Ambil data penyewa yang lama berdasarkan ID
$query = "SELECT * FROM penyewa WHERE id_penyewa = '$id_penyewa'";
$result = mysqli_query($koneksi, $query);

if (mysqli_num_rows($result) == 0) {
    echo "<script>alert('Data penyewa tidak ditemukan di database!'); window.location.href='index.php';</script>";
    exit;
}

$data = mysqli_fetch_assoc($result);

// 3. Proses Update Data ketika tombol "Simpan Perubahan" diklik
if (isset($_POST['update'])) {
    $nama_penyewa = mysqli_real_escape_string($koneksi, $_POST['nama_penyewa']);
    $no_ktp       = mysqli_real_escape_string($koneksi, $_POST['no_ktp']);
    $no_telp      = mysqli_real_escape_string($koneksi, $_POST['no_telp']);
    $email        = mysqli_real_escape_string($koneksi, $_POST['email']);

    // Query UPDATE sesuai dengan struktur kolom databasemu
    $query_update = "UPDATE penyewa SET 
                        nama_penyewa = '$nama_penyewa', 
                        no_ktp = '$no_ktp', 
                        no_telp = '$no_telp', 
                        email = '$email' 
                     WHERE id_penyewa = '$id_penyewa'";

    $update = mysqli_query($koneksi, $query_update);

    if ($update) {
        echo "<script>alert('Data penyewa berhasil diperbarui!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data: " . mysqli_error($koneksi) . "');</script>";
    }
}

// Load UI Layout setelah logika pengecekan selesai
include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold text-dark mb-1">Form Edit Data Penyewa</h3>
                    <p class="text-muted small mb-0">Ubah informasi biodata penghuni kos secara akurat.</p>
                </div>
                <a href="index.php" class="btn btn-light border px-4 py-2 rounded-3 shadow-sm">
                    <i class="fa-solid fa-arrow-left me-2"></i>Kembali
                </a>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-4">
            <form action="" method="POST">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-secondary">NAMA LENGKAP</label>
                        <input type="text" name="nama_penyewa" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" 
                               value="<?= htmlspecialchars($data['nama_penyewa']); ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-secondary">ALAMAT EMAIL</label>
                        <input type="email" name="email" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" 
                               value="<?= htmlspecialchars($data['email']); ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-secondary">NOMOR WHATSAPP / TELEPON</label>
                        <input type="text" name="no_telp" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" 
                               value="<?= htmlspecialchars($data['no_telp']); ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-secondary">NOMOR KTP / IDENTITAS</label>
                        <input type="text" name="no_ktp" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" 
                               value="<?= htmlspecialchars($data['no_ktp']); ?>" maxlength="16" required>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2 mt-4">
                    <a href="index.php" class="btn btn-light px-4 py-2 rounded-3">Batal</a>
                    <button type="submit" name="update" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>