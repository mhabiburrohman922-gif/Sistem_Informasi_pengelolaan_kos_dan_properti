<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// Query JOIN untuk menggabungkan data kontrak, penyewa, dan nomor kamar
// Mengambil juga kolom status_kontrak dari tabel kontrak_sewa
$query = "SELECT kontrak_sewa.*, penyewa.nama_penyewa, kamar.nomor_kamar 
          FROM kontrak_sewa
          JOIN penyewa ON kontrak_sewa.id_penyewa = penyewa.id_penyewa
          JOIN kamar ON kontrak_sewa.id_kamar = kamar.id_kamar";
$result = mysqli_query($koneksi, $query);

include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <div class="row mb-4">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <div>
                <h3 class="fw-bold text-dark mb-1">Transaksi Kontrak Sewa</h3>
                <p class="text-muted small mb-0">Hubungkan data penghuni aktif dengan kamar yang tersedia.</p>
            </div>
            <a href="tambah.php" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">
                <i class="fa-solid fa-plus me-2"></i>Buat Kontrak Baru
            </a>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary fw-semibold small">
                        <tr>
                            <th class="ps-4">NO</th>
                            <th>NAMA PENYEWA</th>
                            <th>NOMOR KAMAR</th>
                            <th>TANGGAL MASUK</th>
                            <th>STATUS KONTRAK</th>
                            <th class="text-center" style="width: 180px;">AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        if(mysqli_num_rows($result) > 0):
                            while($row = mysqli_fetch_assoc($result)): 
                                // Logika penentuan warna badge berdasarkan status kontrak di database
                                $status = isset($row['status_kontrak']) ? $row['status_kontrak'] : 'Aktif';
                                $badge_color = ($status == 'Aktif') ? 'bg-success' : 'bg-danger';
                        ?>
                            <tr>
                                <td class="ps-4"><?= $no++; ?></td>
                                <td class="fw-bold text-dark"><?= $row['nama_penyewa']; ?></td>
                                <td><span class="badge bg-secondary px-3 py-2 rounded-pill"><?= $row['nomor_kamar']; ?></span></td>
                                <td><?= date('d M Y', strtotime($row['tanggal_mulai'])); ?></td>
                                <td><span class="badge <?= $badge_color; ?> px-2 py-1"><?= $status; ?></span></td>
                                <td class="text-center">
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="detail.php?id=<?= $row['id_kontrak']; ?>" class="btn btn-info text-white" title="Detail Kontrak">
                                            <i class="fa-solid fa-eye"></i>
                                        </a>
                                        <a href="edit.php?id=<?= $row['id_kontrak']; ?>" class="btn btn-warning text-white" title="Edit Kontrak">
                                            <i class="fa-solid fa-pen"></i>
                                        </a>
                                        
                                        <?php if($status == 'Aktif'): ?>
                                            <a href="stop.php?id=<?= $row['id_kontrak']; ?>" class="btn btn-danger" title="Stop Kontrak" onclick="return confirm('Apakah Anda yakin ingin menghentikan kontrak sewa ini? Status kamar akan langsung dikosongkan kembali.')">
                                                <i class="fa-solid fa-circle-xmark"></i>
                                            </a>
                                        <?php else: ?>
                                            <a href="hapus.php?id=<?= $row['id_kontrak']; ?>" class="btn btn-danger" title="Hapus Permanen" onclick="return confirm('Apakah Anda yakin ingin menghapus riwayat kontrak ini secara permanen dari sistem?')">
                                                <i class="fa-solid fa-trash"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            endwhile; 
                        else:
                        ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted small">Belum ada kontrak sewa aktif. Klik 'Buat Kontrak Baru' untuk menempatkan penghuni.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>