<?php
// Aktifkan reporting error untuk membantu debugging
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
include '../config/koneksi.php';
/** @var mysqli $koneksi */
// 1. Ambil data penyewa
// Query sing bener (mung nampilne wong sing DURUNG nduwe kontrak):
$penyewa_res = mysqli_query($koneksi, "SELECT * FROM penyewa 
    WHERE id_penyewa NOT IN (SELECT id_penyewa FROM kontrak_sewa)");

// 2. Ambil data kamar KHUSUS yang tersedia saja (Disesuaikan dengan kolom 'status_kamar')
$kamar_res = mysqli_query($koneksi, "SELECT * FROM kamar WHERE status_kamar = 'Tersedia'");

if (isset($_POST['proses_kontrak'])) {
    $id_penyewa     = mysqli_real_escape_string($koneksi, $_POST['id_penyewa']);
    $id_kamar       = mysqli_real_escape_string($koneksi, $_POST['id_kamar']);
    $tgl_mulai      = mysqli_real_escape_string($koneksi, $_POST['tanggal_mulai']);
    $tgl_mulai_kont = mysqli_real_escape_string($koneksi, $_POST['tanggal_mulai_kontrak']);
    $tgl_akhir_kont = mysqli_real_escape_string($koneksi, $_POST['tanggal_akhir_kontrak']);

    try {
        // --- VALIDASI TAMBAHAN ---
        // Cek ulang menggunakan kolom 'status_kamar'
        $cek = mysqli_query($koneksi, "SELECT status_kamar FROM kamar WHERE id_kamar = '$id_kamar'");
        $data_cek = mysqli_fetch_assoc($cek);

        if ($data_cek['status_kamar'] !== 'Tersedia') {
            throw new Exception("Maaf, kamar ini sudah terisi oleh orang lain!");
        }

        // --- INSERT KONTRAK ---
        // Memperbaiki nama variabel $tgl_mulai_kont yang typo sebelumnya
        $query = "INSERT INTO kontrak_sewa 
                  (id_penyewa, id_kamar, tanggal_mulai, tanggal_mulai_kontrak, tanggal_akhir_kontrak, status_kontrak) 
                  VALUES 
                  ('$id_penyewa', '$id_kamar', '$tgl_mulai', '$tgl_mulai_kont', '$tgl_akhir_kont', 'Aktif')";
        
        mysqli_query($koneksi, $query);

        // --- UPDATE STATUS KAMAR ---
        // Mengubah status_kamar menjadi 'Terisi' (Sesuai ENUM di database kamu)
        mysqli_query($koneksi, "UPDATE kamar SET status_kamar = 'Terisi' WHERE id_kamar = '$id_kamar'");

        echo "<script>alert('Kontrak berhasil dibuat!'); window.location.href='index.php';</script>";
        exit;

    } catch (Exception $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "'); history.back();</script>";
    }
}

include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <h3 class="fw-bold mb-4">Buat Kontrak Sewa Baru</h3>
    <div class="card border-0 shadow-sm p-4">
        <form action="" method="POST">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Pilih Penyewa</label>
                    <select name="id_penyewa" class="form-select" required>
                        <option value="">-- Pilih Penyewa --</option>
                        <?php while($p = mysqli_fetch_assoc($penyewa_res)) { ?>
                            <option value="<?= $p['id_penyewa'] ?>"><?= $p['nama_penyewa'] ?></option>
                        <?php } ?>
                    </select>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Pilih Kamar (Hanya yang Tersedia)</label>
                    <select name="id_kamar" class="form-select" required>
                        <option value="">-- Pilih Kamar --</option>
                        <?php 
                        if (mysqli_num_rows($kamar_res) == 0) {
                            echo "<option disabled>Semua kamar sudah terisi</option>";
                        } else {
                            while($k = mysqli_fetch_assoc($kamar_res)) {
                                echo "<option value='".$k['id_kamar']."'>".$k['nomor_kamar']."</option>";
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Tanggal Masuk (Awal)</label>
                    <input type="date" name="tanggal_mulai" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tanggal Mulai Kontrak</label>
                    <input type="date" name="tanggal_mulai_kontrak" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tanggal Akhir Kontrak</label>
                    <input type="date" name="tanggal_akhir_kontrak" class="form-control" required>
                </div>
            </div>
            <button type="submit" name="proses_kontrak" class="btn btn-primary mt-4">Simpan Kontrak</button>
        </form>
    </div>
</div>

<?php include '../layout/footer.php'; ?>