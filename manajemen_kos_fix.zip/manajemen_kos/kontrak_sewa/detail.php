<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// 1. Tangkap ID dari URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id_kontrak = mysqli_real_escape_string($koneksi, $_GET['id']);

// 2. Query buat narik data lengkap berdasarkan ID kontrak tersebut
$query = "SELECT kontrak_sewa.*, penyewa.*, kamar.nomor_kamar 
          FROM kontrak_sewa
          JOIN penyewa ON kontrak_sewa.id_penyewa = penyewa.id_penyewa
          JOIN kamar ON kontrak_sewa.id_kamar = kamar.id_kamar
          WHERE kontrak_sewa.id_kontrak = '$id_kontrak'";

$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

// Jika data tidak ditemukan
if (!$data) {
    echo "<script>alert('Data kontrak tidak ditemukan!'); window.location='index.php';</script>";
    exit;
}

include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <div class="row mb-4">
        <div class="col-12">
            <h3 class="fw-bold text-dark mb-1">Detail Kontrak Sewa</h3>
            <p class="text-muted small">Informasi lengkap masa sewa penghuni.</p>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-4">
            <h5 class="fw-bold text-primary mb-4">Informasi Penghuni & Kamar</h5>
            <table class="table table-bordered">
                <tr>
                    <th width="30%">Nama Penyewa</th>
                    <td><?= $data['nama_penyewa']; ?></td>
                </tr>
                <tr>
                    <th>Nomor Kamar</th>
                    <td><span class="badge bg-secondary"><?= $data['nomor_kamar']; ?></span></td>
                </tr>
                <tr>
                    <th>Tanggal Masuk</th>
                    <td><?= date('d F Y', strtotime($data['tanggal_mulai'])); ?></td>
                </tr>
                <tr>
                    <th>Status Kontrak</th>
                    <td><span class="badge bg-success"><?= isset($data['status_kontrak']) ? $data['status_kontrak'] : 'Aktif'; ?></span></td>
                </tr>
                </table>

            <div class="mt-4">
                <a href="index.php" class="btn btn-secondary px-4">Kembali</a>
            </div>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>