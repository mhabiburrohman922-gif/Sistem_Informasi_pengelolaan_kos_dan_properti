<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// 1. Cek apakah ada ID yang dikirim melalui URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id_kontrak = mysqli_real_escape_string($koneksi, $_GET['id']);

// 2. Query untuk mengambil data kontrak lama yang mau diedit
$query_kontrak = "SELECT * FROM kontrak_sewa WHERE id_kontrak = '$id_kontrak'";
$result_kontrak = mysqli_query($koneksi, $query_kontrak);
$data_kontrak = mysqli_fetch_assoc($result_kontrak);

if (!$data_kontrak) {
    echo "<script>alert('Data kontrak tidak ditemukan!'); window.location='index.php';</script>";
    exit;
}

// Simpan id_kamar lama sebelum diubah oleh user untuk keperluan sinkronisasi
$id_kamar_lama = $data_kontrak['id_kamar']; 

// 3. Ambil data semua penyewa untuk pilihan dropdown
$query_penyewa = "SELECT id_penyewa, nama_penyewa FROM penyewa";
$result_penyewa = mysqli_query($koneksi, $query_penyewa);

// Query Kamar Menggunakan LEFT JOIN untuk mendeteksi apakah kamar tersebut sedang aktif diisi ORANG LAIN
$query_kamar = "SELECT kamar.id_kamar, kamar.nomor_kamar, kontrak_sewa.id_kontrak AS kamar_terisi 
                FROM kamar 
                LEFT JOIN kontrak_sewa ON kamar.id_kamar = kontrak_sewa.id_kamar 
                AND kontrak_sewa.status_kontrak = 'Aktif' 
                AND kontrak_sewa.id_kontrak != '$id_kontrak'";
$result_kamar = mysqli_query($koneksi, $query_kamar);

// 4. Proses Simpan Perubahan (Saat tombol "Simpan Perubahan" diklik)
if (isset($_POST['update'])) {
    $id_penyewa = mysqli_real_escape_string($koneksi, $_POST['id_penyewa']);
    $id_kamar_baru = mysqli_real_escape_string($koneksi, $_POST['id_kamar']);
    $tanggal_mulai = mysqli_real_escape_string($koneksi, $_POST['tanggal_mulai']);
    $status_kontrak = mysqli_real_escape_string($koneksi, $_POST['status_kontrak']);

    // Mulai database transaction agar aman
    mysqli_begin_transaction($koneksi);

    try {
        // A. Query Update Data Kontrak Utama
        $query_update = "UPDATE kontrak_sewa SET 
                         id_penyewa = '$id_penyewa', 
                         id_kamar = '$id_kamar_baru', 
                         tanggal_mulai = '$tanggal_mulai',
                         status_kontrak = '$status_kontrak'
                         WHERE id_kontrak = '$id_kontrak'";
        mysqli_query($koneksi, $query_update);

        // B. Logika Sinkronisasi Menggunakan Kolom 'status_kamar'
        if ($status_kontrak == 'Aktif') {
            // Jika kontrak diset AKTIF namun kamar berubah (pindah kamar)
            if ($id_kamar_lama != $id_kamar_baru) {
                // Set kamar yang lama menjadi 'Tersedia' kembali
                $query_kosongkan_lama = "UPDATE kamar SET status_kamar = 'Tersedia' WHERE id_kamar = '$id_kamar_lama'";
                mysqli_query($koneksi, $query_kosongkan_lama);
            }
            // Set kamar yang baru menjadi 'Terisi'
            $query_isi_baru = "UPDATE kamar SET status_kamar = 'Terisi' WHERE id_kamar = '$id_kamar_baru'";
            mysqli_query($koneksi, $query_isi_baru);

        } else if ($status_kontrak == 'Selesai') {
            // Jika status kontrak diubah menjadi SELESAI, maka kamar lama & baru otomatis diset 'Tersedia'
            $query_kosongkan_lama = "UPDATE kamar SET status_kamar = 'Tersedia' WHERE id_kamar = '$id_kamar_lama'";
            mysqli_query($koneksi, $query_kosongkan_lama);
            
            $query_kosongkan_baru = "UPDATE kamar SET status_kamar = 'Tersedia' WHERE id_kamar = '$id_kamar_baru'";
            mysqli_query($koneksi, $query_kosongkan_baru);
        }

        // Jika semua sukses, commit ke database
        mysqli_commit($koneksi);

        echo "<script>alert('Data kontrak dan status kamar berhasil diperbarui!'); window.location='index.php';</script>";
        exit;

    } catch (Exception $e) {
        // Jika ada yang gagal, batalkan semua perubahan query di atas
        mysqli_rollback($koneksi);
        $error_msg = mysqli_real_escape_string($koneksi, $e->getMessage());
        echo "<script>alert('Gagal memperbarui data: $error_msg');</script>";
    }
}

include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <div class="row mb-4">
        <div class="col-12">
            <h3 class="fw-bold text-dark mb-1">Edit Kontrak Sewa</h3>
            <p class="text-muted small">Ubah informasi atau perbaiki kesalahan input kontrak sewa.</p>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4" style="max-width: 600px;">
        <div class="card-body p-4">
            <form action="" method="POST">
                
                <div class="mb-3">
                    <label for="id_penyewa" class="form-label fw-semibold text-secondary small">Nama Penyewa</label>
                    <select class="form-select" name="id_penyewa" id="id_penyewa" required>
                        <?php while($p = mysqli_fetch_assoc($result_penyewa)): ?>
                            <option value="<?= $p['id_penyewa']; ?>" <?= ($p['id_penyewa'] == $data_kontrak['id_penyewa']) ? 'selected' : ''; ?>>
                                <?= $p['nama_penyewa']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="id_kamar" class="form-label fw-semibold text-secondary small">Nomor Kamar</label>
                    <select class="form-select" name="id_kamar" id="id_kamar" required>
                        <?php 
                        while($k = mysqli_fetch_assoc($result_kamar)): 
                            // Apakah ini kamar yang emang sedang dia tempati sekarang?
                            $is_current_room = ($k['id_kamar'] == $data_kontrak['id_kamar']);
                            // Apakah kamar ini diisi orang lain secara aktif?
                            $is_occupied_by_others = (!empty($k['kamar_terisi']));
                        ?>
                            <option value="<?= $k['id_kamar']; ?>" 
                                <?= $is_current_room ? 'selected' : ''; ?> 
                                <?= ($is_occupied_by_others && !$is_current_room) ? 'disabled' : ''; ?>>
                                Kamar <?= $k['nomor_kamar']; ?> <?= ($is_occupied_by_others && !$is_current_room) ? '(Terisi)' : ''; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="tanggal_mulai" class="form-label fw-semibold text-secondary small">Tanggal Masuk</label>
                    <input type="date" class="form-control" name="tanggal_mulai" id="tanggal_mulai" value="<?= $data_kontrak['tanggal_mulai']; ?>" required>
                </div>

                <div class="mb-4">
                    <label for="status_kontrak" class="form-label fw-semibold text-secondary small">Status Kontrak</label>
                    <select class="form-select" name="status_kontrak" id="status_kontrak" required>
                        <option value="Aktif" <?= ($data_kontrak['status_kontrak'] == 'Aktif' || !isset($data_kontrak['status_kontrak'])) ? 'selected' : ''; ?>>Aktif</option>
                        <option value="Selesai" <?= (isset($data_kontrak['status_kontrak']) && $data_kontrak['status_kontrak'] == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
                    </select>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" name="update" class="btn btn-primary px-4">Simpan Perubahan</button>
                    <a href="index.php" class="btn btn-light border px-4">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>