<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// 1. Cek apakah ada ID kontrak yang dikirim melalui URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_kontrak = mysqli_real_escape_string($koneksi, $_GET['id']);

    // 2. Query untuk mengubah status_kontrak dari 'Aktif' menjadi 'Selesai'
    // Ini mengubah status kontrak lama agar kamarnya otomatis dianggap kosong oleh sistem
    $query_stop = "UPDATE kontrak_sewa SET status_kontrak = 'Selesai' WHERE id_kontrak = '$id_kontrak'";

    if (mysqli_query($koneksi, $query_stop)) {
        echo "<script>
                alert('Kontrak sewa berhasil dihentikan! Status kamar sekarang telah tersedia kembali.');
                window.location = 'index.php';
              </script>";
        exit;
    } else {
        echo "<script>
                alert('Gagal menghentikan kontrak: " . mysqli_error($koneksi) . "');
                window.location = 'index.php';
              </script>";
        exit;
    }
} else {
    // Jika diakses langsung tanpa ID, kembalikan ke halaman utama
    header("Location: index.php");
    exit;
}
?>