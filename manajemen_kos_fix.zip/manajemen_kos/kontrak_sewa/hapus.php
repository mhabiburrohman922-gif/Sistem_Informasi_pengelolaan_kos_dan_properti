<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../config/koneksi.php';
/** @var mysqli $koneksi */

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_kontrak = mysqli_real_escape_string($koneksi, $_GET['id']);

    try {
        // 1. Hapus terlebih dahulu data di tabel anak (tagihan_sewa) yang terikat dengan id_kontrak ini
        $query_hapus_tagihan = "DELETE FROM tagihan_sewa WHERE id_kontrak = '$id_kontrak'";
        mysqli_query($koneksi, $query_hapus_tagihan);

        // 2. Setelah data anak bersih, baru hapus data induknya (kontrak_sewa)
        $query_hapus_kontrak = "DELETE FROM kontrak_sewa WHERE id_kontrak = '$id_kontrak'";
        
        if (mysqli_query($koneksi, $query_hapus_kontrak)) {
            echo "<script>
                    alert('Riwayat kontrak beserta data tagihannya berhasil dihapus permanen!');
                    window.location = 'index.php';
                  </script>";
            exit;
        }
    } catch (mysqli_sql_exception $e) {
        $pesan_error = $e->getMessage();
        echo "<script>
                alert('Gagal menghapus data! \\n\\nDetail Error: $pesan_error');
                window.location = 'index.php';
              </script>";
        exit;
    }
} else {
    header("Location: index.php");
    exit;
}
?>