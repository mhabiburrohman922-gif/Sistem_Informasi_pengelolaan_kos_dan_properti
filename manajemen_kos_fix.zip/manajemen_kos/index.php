<?php
session_start();

// Jika sudah login, arahkan ke dashboard
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header("Location: dashboard.php");
    exit;
}

// Jika belum login, arahkan ke halaman login
header("Location: login.php");
exit;
?>
