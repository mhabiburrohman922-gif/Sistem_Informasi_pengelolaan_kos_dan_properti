<?php 
// 1. Aktifkan penangkap error untuk debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2. Panggil koneksi dan komponen layouting
include_once 'config/koneksi.php'; 
include_once 'layout/header.php';
include_once 'layout/sidebar.php';

// ==========================================
// LOGIKA QUERY DATA DYNAMIC (REAL-TIME DATABASE)
// ==========================================

// A. Menghitung Ringkasan Data Kamar
$query_total_kamar = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM kamar");
$data_total_kamar  = mysqli_fetch_assoc($query_total_kamar)['total'];

$query_terisi = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM kamar WHERE status_kamar = 'Terisi'");
$data_terisi  = mysqli_fetch_assoc($query_terisi)['total'];

$query_kosong = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM kamar WHERE status_kamar = 'Tersedia'");
$data_kosong  = mysqli_fetch_assoc($query_kosong)['total'];

// B. Menghitung Total Pendapatan Bulan Ini (Arus Kas Masuk)
$query_pendapatan = mysqli_query($koneksi, "
    SELECT SUM(p.jumlah_bayar) AS total_masuk 
    FROM pembayaran_sewa p
    JOIN tagihan_sewa t ON p.id_tagihan = t.id_tagihan
    WHERE MONTH(t.tanggal_jatuh_tempo) = MONTH(CURDATE()) 
      AND YEAR(t.tanggal_jatuh_tempo) = YEAR(CURDATE())
");
$pendapatan_bulan_ini = mysqli_fetch_assoc($query_pendapatan)['total_masuk'] ?? 0;
?>

<div class="container-fluid px-0 mb-5">
    
    <div class="mb-4">
        <h4 class="fw-bold text-dark mb-1">Panel Analitik Utama</h4>
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb mb-0" style="font-size: 0.85rem;">
                <li class="breadcrumb-item"><a href="#" class="text-decoration-none text-muted">Home</a></li>
                <li class="breadcrumb-item active text-primary" aria-current="page">Dashboard</li>
            </ol>
        </nav>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card border-0 text-white p-3 h-100 shadow-sm" style="background-color: #448aff; border-radius: 8px;">
                <h6 class="text-white-50 fw-normal mb-1" style="font-size: 0.85rem;">Total Kamar</h6>
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h2 class="mb-0 fw-bold"><?= $data_total_kamar; ?></h2>
                        <span class="text-white-50" style="font-size: 0.75rem;">Unit Kamar Terdaftar</span>
                    </div>
                    <div style="width: 50px; opacity: 0.4; font-size: 2rem;" class="text-end">
                        <i class="fa-solid fa-door-open"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-0 text-white p-3 h-100 shadow-sm" style="background-color: #11c15b; border-radius: 8px;">
                <h6 class="text-white-50 fw-normal mb-1" style="font-size: 0.85rem;">Kamar Terisi</h6>
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h2 class="mb-0 fw-bold"><?= $data_terisi; ?></h2>
                        <span class="text-white-50" style="font-size: 0.75rem;">Hunian Aktif Saat Ini</span>
                    </div>
                    <div style="width: 50px; opacity: 0.4; font-size: 2rem;" class="text-end">
                        <i class="fa-solid fa-user-group"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-0 text-white p-3 h-100 shadow-sm" style="background-color: #ffb64d; border-radius: 8px;">
                <h6 class="text-white-50 fw-normal mb-1" style="font-size: 0.85rem;">Kamar Kosong</h6>
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h2 class="mb-0 fw-bold"><?= $data_kosong; ?></h2>
                        <span class="text-white-50" style="font-size: 0.75rem;">Siap Menerima Penyewa</span>
                    </div>
                    <div style="width: 50px; opacity: 0.4; font-size: 2rem;" class="text-end">
                        <i class="fa-solid fa-bed"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-0 text-white p-3 h-100 shadow-sm" style="background-color: #696ffb; border-radius: 8px;">
                <h6 class="text-white-50 fw-normal mb-1" style="font-size: 0.85rem;">Pendapatan Bulan Ini</h6>
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h2 class="mb-0 fw-bold" style="font-size: 1.25rem;">Rp <?= number_format($pendapatan_bulan_ini, 0, ',', '.'); ?></h2>
                        <span class="text-white-50" style="font-size: 0.75rem;">Arus Kas Masuk Terpembayar</span>
                    </div>
                    <div style="width: 50px; opacity: 0.4; font-size: 2rem;" class="text-end">
                        <i class="fa-solid fa-wallet"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm p-3 bg-white mb-4" style="border-radius: 8px;">
        <p class="text-muted small m-0">
            <i class="fa-solid fa-circle-check text-success me-2"></i><strong>Sinkronisasi Sukses:</strong> Panel ini terhubung langsung dengan fungsi optimasi database (Stored Procedure, VIEW, dan Triggers) untuk menjamin validitas pelaporan.
        </p>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm" style="border-radius: 8px;">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-0">
                    <h5 class="fw-bold text-dark mb-0" style="font-size: 1.1rem;">Daftar Tunggakan Aktif (SQL VIEW)</h5>
                    <span class="badge bg-danger bg-opacity-10 text-danger px-2 py-1">Butuh Tindakan</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" style="font-size: 0.9rem;">
                            <thead class="table-light text-muted" style="font-size: 0.8rem;">
                                <tr>
                                    <th class="ps-3">NOMOR KAMAR</th>
                                    <th>ID PENYEWA</th>
                                    <th>PERIODE TUNGGAKAN</th>
                                    <th class="text-end pe-3">TOTAL TAGIHAN</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query_view = mysqli_query($koneksi, "SELECT * FROM view_tunggakan_sewa LIMIT 5");
                                if ($query_view && mysqli_num_rows($query_view) > 0) {
                                    while ($row = mysqli_fetch_assoc($query_view)) {
                                        echo "<tr>";
                                        echo "<td class='ps-3 fw-bold text-dark'><span class='badge bg-light text-primary border border-primary-subtle px-2 py-1'>Kamar " . htmlspecialchars($row['nomor_kamar']) . "</span></td>";
                                        echo "<td><span class='text-muted'>#Pny-</span>" . htmlspecialchars($row['id_penyewa']) . "</td>";
                                        echo "<td class='text-muted'>" . htmlspecialchars($row['bulan_tunggak']) . "</td>";
                                        echo "<td class='fw-bold text-danger text-end pe-3'>Rp " . number_format($row['total_tunggakan'], 0, ',', '.') . "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='4' class='text-center text-muted py-4'><i class='fa-solid fa-face-smile text-success me-2'></i> Tidak ada tunggakan sewa terdeteksi bulan ini.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100" style="border-radius: 8px;">
                <div class="card-header bg-white py-3 border-0">
                    <h5 class="fw-bold text-dark mb-0" style="font-size: 1.1rem;">Laporan Arus Kas Bulanan</h5>
                </div>
                <div class="card-body pt-1">
                    <?php
                    // FIX QUERY GROUP BY HIERARCHY
                    $query_arus_kas = mysqli_query($koneksi, "
                        SELECT 
                            DATE_FORMAT(t.tanggal_jatuh_tempo, '%b %Y') AS bulan,
                            SUM(p.jumlah_bayar) AS total_masuk
                        FROM pembayaran_sewa p
                        JOIN tagihan_sewa t ON p.id_tagihan = t.id_tagihan
                        GROUP BY DATE_FORMAT(t.tanggal_jatuh_tempo, '%b %Y'), YEAR(t.tanggal_jatuh_tempo), MONTH(t.tanggal_jatuh_tempo)
                        ORDER BY YEAR(t.tanggal_jatuh_tempo) DESC, MONTH(t.tanggal_jatuh_tempo) DESC 
                        LIMIT 3
                    ");

                    if ($query_arus_kas && mysqli_num_rows($query_arus_kas) > 0) {
                        while ($kas = mysqli_fetch_assoc($query_arus_kas)) {
                    ?>
                            <div class="d-flex mb-3 border-start border-primary border-3 ps-3 py-2 bg-light rounded-2 align-items-center justify-content-between">
                                <div>
                                    <div class="fw-bold text-dark" style="font-size: 0.85rem;">Periode <?= htmlspecialchars($kas['bulan']); ?></div>
                                    <small class="text-muted" style="font-size: 0.75rem;"><i class="fa-solid fa-arrow-down-long text-success me-1"></i> Arus Kas Masuk Bersih</small>
                                </div>
                                <div class="text-end">
                                    <span class="fw-bold text-success" style="font-size: 0.95rem;">+ Rp <?= number_format($kas['total_masuk'], 0, ',', '.'); ?></span>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                        echo "<div class='text-center text-muted py-5'><i class='fa-solid fa-chart-line fa-2x mb-2 d-block opacity-25'></i>Belum ada data transaksi tercatat.</div>";
                    }
                    ?>
                </div>
            </div>
        </div>

    </div>
</div>

<?php 
include_once 'layout/footer.php';
?>