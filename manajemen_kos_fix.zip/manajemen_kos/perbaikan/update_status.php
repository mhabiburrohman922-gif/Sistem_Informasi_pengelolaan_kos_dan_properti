<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// Pastikan parameter id dan status ada di URL
if (isset($_GET['id']) && isset($_GET['status'])) {
    
    // Mengamankan input data dari URL
    $id_perbaikan = mysqli_real_escape_string($koneksi, $_GET['id']);
    $status_baru  = mysqli_real_escape_string($koneksi, $_GET['status']);

    // Validasi ketat agar status yang masuk hanya Menunggu, Proses, atau Selesai
    $status_valid = ['Menunggu', 'Proses', 'Selesai'];

    if (in_array($status_baru, $status_valid)) {
        
        // Query untuk mengupdate status_perbaikan berdasarkan ID-nya
        $query_update = "UPDATE permintaan_perbaikan 
                         SET status_perbaikan = '$status_baru' 
                         WHERE id_perbaikan = '$id_perbaikan'";
                         
        if (mysqli_query($koneksi, $query_update)) {
            // Jika berhasil, munculkan alert sukses lalu redirect balik ke index.php
            echo "<script>
                    alert('Status laporan sukses diperbarui menjadi: $status_baru!');
                    window.location.href = 'index.php';
                  </script>";
            exit();
        } else {
            // Jika query gagal running
            echo "<script>
                    alert('Gagal memperbarui database! Error: " . mysqli_error($koneksi) . "');
                    window.location.href = 'index.php';
                  </script>";
            exit();
        }
    } else {
        // Jika status yang dikirim lewat URL tidak valid (aneh-aneh)
        echo "<script>
                alert('Status tidak dikenali oleh sistem!');
                window.location.href = 'index.php';
              </script>";
        exit();
    }
}

// Jika file ini diakses langsung secara ilegal tanpa parameter id/status, tendang balik ke index.php
header("Location: index.php");
exit();
?>