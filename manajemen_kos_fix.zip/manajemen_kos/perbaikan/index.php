<?php
include '../config/koneksi.php';
include '../layout/header.php';
include '../layout/sidebar.php';
/** @var mysqli $koneksi */

// 1. Ambil data statistik ringkas berdasarkan kolom status_perbaikan asli
$total_keluhan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM permintaan_perbaikan"))['total'] ?? 0;
$total_pending = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM permintaan_perbaikan WHERE status_perbaikan = 'Menunggu'"))['total'] ?? 0;
$total_selesai = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM permintaan_perbaikan WHERE status_perbaikan = 'Selesai'"))['total'] ?? 0;
?>

<div class="container-fluid px-2 px-md-3 mt-3">
    <div class="d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between p-3 bg-white rounded-3 shadow-sm mb-4 gap-2">
        <div>
            <h4 class="fw-bold text-dark mb-1">
                <i class="fa-solid fa-screwdriver-wrench text-primary me-2"></i>Permintaan Perbaikan
            </h4>
            <p class="text-muted small mb-0 d-none d-md-block">Daftar keluhan fasilitas kamar atau area kos dari penghuni yang butuh tindakan teknisi.</p>
        </div>
        <button class="btn btn-sm btn-light border text-secondary align-self-end align-self-md-center" onclick="window.location.reload();">
            <i class="fa-solid fa-rotate me-1"></i> Refresh Data
        </button>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-12 col-sm-6 col-md-4">
            <div class="card border-0 shadow-sm rounded-3 bg-gradient bg-primary text-white p-2">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50 small text-uppercase fw-bold mb-1" style="letter-spacing: 0.5px;">Total Keluhan</h6>
                        <h3 class="fw-bold mb-0"><?= $total_keluhan; ?> Laporan</h3>
                    </div>
                    <div class="bg-white p-3 rounded-3 d-flex align-items-center justify-content-center shadow-sm" style="width: 52px; height: 52px;">
                        <i class="fa-solid fa-clipboard-list fs-4 text-primary"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4">
            <div class="card border-0 shadow-sm rounded-3 bg-gradient bg-warning text-white p-2">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50 small text-uppercase fw-bold mb-1" style="letter-spacing: 0.5px;">Menunggu (Butuh Proses)</h6>
                        <h3 class="fw-bold mb-0"><?= $total_pending; ?> Antrean</h3>
                    </div>
                    <div class="bg-white p-3 rounded-3 d-flex align-items-center justify-content-center shadow-sm" style="width: 52px; height: 52px;">
                        <i class="fa-solid fa-hourglass-half fs-4 text-warning"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4">
            <div class="card border-0 shadow-sm rounded-3 bg-gradient bg-success text-white p-2">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50 small text-uppercase fw-bold mb-1" style="letter-spacing: 0.5px;">Selesai Diperbaiki</h6>
                        <h3 class="fw-bold mb-0"><?= $total_selesai; ?> Kasus</h3>
                    </div>
                    <div class="bg-white p-3 rounded-3 d-flex align-items-center justify-content-center shadow-sm" style="width: 52px; height: 52px;">
                        <i class="fa-solid fa-circle-check fs-4 text-success"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-header bg-white py-3 border-0 d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-2">
            <h6 class="m-0 fw-bold text-secondary"><i class="fa-solid fa-tools me-2"></i>Log Request Perbaikan</h6>
            <a href="tambah.php" class="btn btn-sm btn-primary rounded-2 shadow-xs w-100 w-sm-auto">
                <i class="fa-solid fa-plus me-1"></i> Tambah Laporan
            </a>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light text-uppercase text-secondary" style="font-size: 0.8rem; letter-spacing: 0.5px;">
                        <tr>
                            <th class="ps-4 py-3" style="width: 5%">No</th>
                            <th class="py-3" style="width: 15%">Nama Penyewa</th>
                            <th class="py-3" style="width: 10%">Kamar</th>
                            <th class="py-3" style="width: 27%">Deskripsi Kerusakan</th>
                            <th class="py-3" style="width: 15%">Tanggal Masuk</th>
                            <th class="py-3 text-center" style="width: 13%">Status</th>
                            <th class="py-3 text-center" style="width: 15%">Aksi</th> </tr>
                    </thead>
                    <tbody class="text-dark" style="font-size: 0.9rem;">
                        <?php
                        $query = "SELECT permintaan_perbaikan.*, kamar.nomor_kamar, penyewa.nama_penyewa 
                                  FROM permintaan_perbaikan
                                  JOIN kamar ON permintaan_perbaikan.id_kamar = kamar.id_kamar
                                  LEFT JOIN kontrak_sewa ON kamar.id_kamar = kontrak_sewa.id_kamar
                                  LEFT JOIN penyewa ON kontrak_sewa.id_penyewa = penyewa.id_penyewa
                                  ORDER BY permintaan_perbaikan.id_perbaikan DESC";

                        $result = mysqli_query($koneksi, $query);

                        if (!$result) {
                            echo "<tr><td colspan='7' class='text-center text-danger p-4'><i class='fa-solid fa-triangle-exclamation me-2'></i>Gagal memuat data: " . mysqli_error($koneksi) . "</td></tr>";
                        } elseif (mysqli_num_rows($result) == 0) {
                            echo "<tr><td colspan='7' class='text-center text-muted p-5'>
                                    <i class='fa-solid fa-screwdriver-wrench fs-1 text-black-50 mb-3 d-block'></i>
                                    Aman! Belum ada laporan kerusakan fasilitas di tabel database.
                                  </td></tr>";
                        } else {
                            $no = 1;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $status = $row['status_perbaikan'] ?? 'Menunggu'; 
                                $badge_class = "bg-warning text-dark"; 
                                if ($status == 'Proses') { $badge_class = "bg-primary text-white"; }
                                elseif ($status == 'Selesai') { $badge_class = "bg-success text-white"; }
                                
                                $nama_user = (!empty($row['nama_penyewa'])) ? $row['nama_penyewa'] : '<span class="text-muted fw-normal">Tidak ada penghuni</span>';
                                ?>
                                <tr>
                                    <td class="ps-4 fw-semibold text-muted"><?= $no++; ?></td>
                                    <td class="fw-bold text-secondary"><?= $nama_user; ?></td>
                                    <td>
                                        <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill px-3 py-1 fw-medium">
                                            Kamar <?= $row['nomor_kamar']; ?>
                                        </span>
                                    </td>
                                    <td class="text-muted text-wrap text-break">
                                        <?= $row['deskripsi']; ?>
                                    </td>
                                    <td class="text-muted small">
                                        <i class="fa-regular fa-calendar-check me-1 text-secondary"></i> 
                                        <?= date('d M Y', strtotime($row['tanggal_permintaan'])); ?>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge <?= $badge_class; ?> w-100 py-2 rounded-3 fw-bold text-uppercase shadow-xs" style="font-size: 0.75rem;">
                                            <?= $status; ?>
                                        </span>
                                    </td>
                                    <td class="text-center pe-4">
                                        <?php if ($status == 'Menunggu'): ?>
                                            <a href="update_status.php?id=<?= $row['id_perbaikan']; ?>&status=Proses" class="btn btn-sm btn-outline-primary py-1 px-2 w-100 fw-semibold" onclick="return confirm('Mulai proses perbaikan kamar ini?')">
                                                <i class="fa-solid fa-gears me-1"></i> Proses
                                            </a>
                                        <?php elseif ($status == 'Proses'): ?>
                                            <a href="update_status.php?id=<?= $row['id_perbaikan']; ?>&status=Selesai" class="btn btn-sm btn-outline-success py-1 px-2 w-100 fw-semibold" onclick="return confirm('Nyatakan perbaikan ini telah selesai?')">
                                                <i class="fa-solid fa-check-double me-1"></i> Selesai
                                            </a>
                                        <?php else: ?>
                                            <span class="text-success small fw-bold"><i class="fa-solid fa-circle-check"></i> Selesai</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>