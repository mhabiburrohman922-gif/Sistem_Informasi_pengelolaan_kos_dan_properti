<?php
// 1. Pelacak Error (Wajib aktif untuk melihat penyebab layar putih polos)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 
include '../config/koneksi.php';
include '../layout/header.php';
include '../layout/sidebar.php';
/** @var mysqli $koneksi */

// 2. Proses Simpan Laporan Kerusakan
if (isset($_POST['submit_laporan'])) {
    $id_kamar = $_POST['id_kamar'];
    $deskripsi = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);
    $tanggal_permintaan = $_POST['tanggal_permintaan'];

    // KUNCI PERBAIKAN: status_perbaikan dihapus dari query agar database menggunakan nilai DEFAULT bawaannya sendiri
    $query_insert = "INSERT INTO permintaan_perbaikan (id_kamar, tanggal_permintaan, deskripsi) 
                     VALUES ('$id_kamar', '$tanggal_permintaan', '$deskripsi')";
    
    if (mysqli_query($koneksi, $query_insert)) {
        echo "<script>
                alert('Laporan kerusakan berhasil disimpan!');
                window.location.href = 'index.php';
              </script>";
        exit();
    } else {
        // Jika query gagal, ini akan menampilkan error spesifik dari MySQL
        die("Gagal menyimpan ke database! Error: " . mysqli_error($koneksi));
    }
}
?>

<div class="container-fluid px-2 px-md-3 mt-3">
    <div class="d-flex align-items-center p-3 bg-white rounded-3 shadow-sm mb-4">
        <div class="bg-primary bg-opacity-10 p-2 rounded-3 me-3 text-primary">
            <i class="fa-solid fa-plus fs-4"></i>
        </div>
        <div>
            <h4 class="fw-bold text-dark mb-1">Tambah Laporan Kerusakan</h4>
            <p class="text-muted small mb-0">Formulir untuk mencatat komplain fasilitas kamar atau area kos yang bermasalah.</p>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-lg-8">
            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-header bg-white py-3 border-0">
                    <h6 class="m-0 fw-bold text-secondary">
                        <i class="fa-solid fa-file-invoice me-2"></i>Detail Laporan Masuk
                    </h6>
                </div>
                <div class="card-body p-4 pt-2">
                    <form action="" method="POST">
                        
                        <div class="mb-3">
                            <label for="id_kamar" class="form-label fw-semibold small text-secondary">Pilih Kamar yang Bermasalah <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0 text-muted"><i class="fa-solid fa-door-open"></i></span>
                                <select class="form-select border-start-0 ps-0" id="id_kamar" name="id_kamar" required>
                                    <option value="" selected disabled>-- Pilih Nomor Kamar --</option>
                                    <?php
                                    $q_kamar = mysqli_query($koneksi, "SELECT id_kamar, nomor_kamar FROM kamar ORDER BY nomor_kamar ASC");
                                    if (!$q_kamar) {
                                        die("Gagal mengambil data kamar: " . mysqli_error($koneksi));
                                    }
                                    while($kamar = mysqli_fetch_assoc($q_kamar)) {
                                        echo "<option value='".$kamar['id_kamar']."'>Kamar ".$kamar['nomor_kamar']."</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="tanggal_permintaan" class="form-label fw-semibold small text-secondary">Tanggal Masuk Laporan <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0 text-muted"><i class="fa-regular fa-calendar"></i></span>
                                <input type="date" class="form-control border-start-0 ps-0" id="tanggal_permintaan" name="tanggal_permintaan" value="<?= date('Y-m-d'); ?>" required>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label for="deskripsi" class="form-label fw-semibold small text-secondary">Deskripsi Kerusakan / Keluhan <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" placeholder="Contoh: Lampu utama kamar mati, atau keran air di kamar mandi bocor..." required></textarea>
                            <div class="form-text small text-muted">Tuliskan secara jelas agar mempermudah teknisi saat melakukan perbaikan.</div>
                        </div>

                        <div class="d-flex flex-column flex-sm-row justify-content-end gap-2 border-top pt-3">
                            <a href="index.php" class="btn btn-light border text-secondary px-4 py-2 rounded-2 order-2 order-sm-1">
                                <i class="fa-solid fa-arrow-left me-1"></i> Kembali
                            </a>
                            <button type="submit" name="submit_laporan" class="btn btn-primary px-4 py-2 rounded-2 order-1 order-sm-2 shadow-xs">
                                <i class="fa-solid fa-floppy-disk me-1"></i> Simpan Laporan
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-12 col-lg-4 d-none d-lg-block">
            <div class="card border-0 bg-light p-3 rounded-3 mb-3 border-start border-4 border-primary">
                <h6 class="fw-bold text-dark"><i class="fa-solid fa-circle-info me-2 text-primary"></i>Informasi Sistem</h6>
                <p class="small text-muted mb-0">Setiap laporan baru yang ditambahkan otomatis mengikuti status default dari struktur database Anda. Anda dapat mengubah status ke 'Proses' atau 'Selesai' di halaman utama pelacakan setelah teknisi ditunjuk.</p>
            </div>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>