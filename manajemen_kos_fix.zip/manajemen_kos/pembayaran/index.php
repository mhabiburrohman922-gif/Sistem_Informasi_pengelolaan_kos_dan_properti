<?php
include '../config/koneksi.php';
include '../layout/header.php';
include '../layout/sidebar.php';
/** @var mysqli $koneksi */

// 1. Hitung total pendapatan kos dari tagihan yang statusnya 'Lunas'
$q_pendapatan = mysqli_query($koneksi, "SELECT SUM(jumlah_tagihan) as total FROM tagihan_sewa WHERE status_bayar = 'Lunas'");
$total_pendapatan = mysqli_fetch_assoc($q_pendapatan)['total'] ?? 0;

// 2. Hitung jumlah transaksi yang berhasil
$q_transaksi = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tagihan_sewa WHERE status_bayar = 'Lunas'");
$total_transaksi = mysqli_fetch_assoc($q_transaksi)['total'] ?? 0;
?>

<div class="container-fluid px-2 px-md-3 mt-3">
    <div class="d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between p-3 bg-white rounded-3 shadow-sm mb-4 gap-2">
        <div>
            <h4 class="fw-bold text-dark mb-1">
                <i class="fa-solid fa-credit-card text-primary me-2"></i>Riwayat Pembayaran Sewa
            </h4>
            <p class="text-muted small mb-0">Daftar seluruh transaksi pembayaran kos yang telah lunas dan tercatat di dalam sistem.</p>
        </div>
        <button class="btn btn-sm btn-light border text-secondary align-self-end align-self-md-center" onclick="window.location.reload();">
            <i class="fa-solid fa-rotate me-1"></i> Refresh Data
        </button>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-12 col-md-6">
            <div class="card border-0 shadow-sm rounded-3 bg-gradient bg-primary text-white p-2">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50 small text-uppercase fw-bold mb-1" style="letter-spacing: 0.5px;">Total Pendapatan Kos</h6>
                        <h3 class="fw-bold mb-0">Rp <?= number_format($total_pendapatan, 0, ',', '.'); ?></h3>
                    </div>
                    <div class="bg-white p-3 rounded-3 d-flex align-items-center justify-content-center shadow-sm" style="width: 52px; height: 52px;">
                        <i class="fa-solid fa-wallet fs-4 text-primary"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6">
            <div class="card border-0 shadow-sm rounded-3 bg-gradient bg-success text-white p-2">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50 small text-uppercase fw-bold mb-1" style="letter-spacing: 0.5px;">Transaksi Berhasil</h6>
                        <h3 class="fw-bold mb-0"><?= $total_transaksi; ?> Pembayaran</h3>
                    </div>
                    <div class="bg-white p-3 rounded-3 d-flex align-items-center justify-content-center shadow-sm" style="width: 52px; height: 52px;">
                        <i class="fa-solid fa-circle-check fs-4 text-success"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-header bg-white py-3 border-0">
            <h6 class="m-0 fw-bold text-secondary"><i class="fa-solid fa-list-check me-2"></i>Log Transaksi Masuk</h6>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light text-uppercase text-secondary" style="font-size: 0.8rem; letter-spacing: 0.5px;">
                        <tr>
                            <th class="ps-4 py-3" style="width: 5%">No</th>
                            <th class="py-3" style="width: 20%">Nama Penyewa</th>
                            <th class="py-3" style="width: 15%">Nomor Kamar</th>
                            <th class="py-3" style="width: 15%">Periode Bulan</th>
                            <th class="py-3" style="width: 15%">Jumlah Bayar</th>
                            <th class="py-3" style="width: 15%">Metode</th>
                            <th class="py-3 text-center" style="width: 15%">Status</th>
                        </tr>
                    </thead>
                    <tbody class="text-dark" style="font-size: 0.9rem;">
                        <?php
                        // Query relasi membaca riwayat transaksi dari tagihan_sewa yang sudah Lunas
                        $query = "SELECT tagihan_sewa.*, penyewa.nama_penyewa, kamar.nomor_kamar 
                                  FROM tagihan_sewa
                                  JOIN kontrak_sewa ON tagihan_sewa.id_kontrak = kontrak_sewa.id_kontrak
                                  JOIN penyewa ON kontrak_sewa.id_penyewa = penyewa.id_penyewa
                                  JOIN kamar ON kontrak_sewa.id_kamar = kamar.id_kamar
                                  WHERE tagihan_sewa.status_bayar = 'Lunas'
                                  ORDER BY tagihan_sewa.id_tagihan DESC";

                        $result = mysqli_query($koneksi, $query);

                        if (!$result) {
                            echo "<tr><td colspan='7' class='text-center text-danger p-4'><i class='fa-solid fa-triangle-exclamation me-2'></i>Gagal memuat data: " . mysqli_error($koneksi) . "</td></tr>";
                        } elseif (mysqli_num_rows($result) == 0) {
                            echo "<tr><td colspan='7' class='text-center text-muted p-5'>
                                    <i class='fa-solid fa-money-bill-wave fs-1 text-black-50 mb-3 d-block'></i>
                                    Belum ada riwayat transaksi pembayaran yang lunas.
                                  </td></tr>";
                        } else {
                            $no = 1;
                            while ($row = mysqli_fetch_assoc($result)) {
                                ?>
                                <tr>
                                    <td class="ps-4 fw-semibold text-muted"><?= $no++; ?></td>
                                    <td class="fw-bold text-secondary"><?= $row['nama_penyewa']; ?></td>
                                    <td>
                                        <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill px-3 py-1 fw-medium">
                                            Kamar <?= $row['nomor_kamar']; ?>
                                        </span>
                                    </td>
                                    <td class="text-muted">
                                        <i class="fa-regular fa-calendar me-1"></i> <?= $row['bulan']; ?>
                                    </td>
                                    <td class="fw-bold text-success">
                                        Rp <?= number_format($row['jumlah_tagihan'], 0, ',', '.'); ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border px-2 py-1 small text-wrap">
                                            <i class="fa-solid fa-wallet me-1 text-muted"></i> Cash/Transfer
                                        </span>
                                    </td>
                                    <td class="text-center pe-4">
                                        <span class="badge bg-success text-white w-100 py-2 rounded-3 fw-bold text-uppercase shadow-sm" style="font-size: 0.75rem;">
                                            <i class="fa-solid fa-check-double me-1"></i> Success
                                        </span>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>