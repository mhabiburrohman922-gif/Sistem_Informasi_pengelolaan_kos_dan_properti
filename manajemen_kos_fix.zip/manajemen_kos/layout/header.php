<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartKos Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --sidebar-width: 270px;
            --sidebar-collapsed-width: 80px;
            --sidebar-bg: #1a233a; /* Dark navy premium */
        }

        body {
            background-color: #f4f6f9;
            overflow-x: hidden;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        }

        /* Wrapper Layout Utama */
        .wrapper {
            display: flex;
            width: 100%;
            align-items: stretch;
        }

        /* STYLING SIDEBAR */
        #sidebar {
            min-width: var(--sidebar-width);
            max-width: var(--sidebar-width);
            background: var(--sidebar-bg);
            color: #fff;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            min-height: 100vh;
            z-index: 999;
            box-shadow: 4px 0 10px rgba(0,0,0,0.05);
        }

        /* Ketika Sidebar Dikecilkan (Collapsed) */
        #sidebar.collapsed {
            min-width: var(--sidebar-collapsed-width);
            max-width: var(--sidebar-collapsed-width);
        }

        #sidebar .sidebar-header {
            padding: 20px 24px;
            background: #151c2e;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }

        /* Hilangkan Teks Saat Sidebar Mengecil */
        #sidebar.collapsed .sidebar-header h4, 
        #sidebar.collapsed .menu-text,
        #sidebar.collapsed .sidebar-heading,
        #sidebar.collapsed .sidebar-user {
            display: none !important;
        }

        /* Tampilkan Ikon Logo Saja Saat Mengecil */
        #sidebar.collapsed .logo-icon {
            display: block !important;
        }

        #sidebar ul p.sidebar-heading {
            padding: 20px 24px 8px 24px;
            color: #526484;
            font-size: 0.75rem;
            text-uppercase: uppercase;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 0;
        }

        /* Desain Menu Kapsul/Pill Style */
        #sidebar ul li a {
            padding: 12px 24px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            color: #a3b1cc;
            text-decoration: none;
            transition: all 0.2s ease;
            margin: 4px 16px;
            border-radius: 50px; /* Bentuk Kapsul Melengkung */
        }

        #sidebar ul li a:hover {
            background: rgba(255, 255, 255, 0.04);
            color: #fff;
        }

        #sidebar ul li a i {
            margin-right: 15px;
            width: 20px;
            text-align: center;
            font-size: 1.05rem;
        }

        /* EFEK ACTIVE STATE (Gaya CrmX Admin) */
        #sidebar ul li.active a {
            background: #ffffff !important; /* Latar belakang putih bersih */
            color: #448aff !important; /* Teks berubah jadi biru */
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        #sidebar ul li.active a i {
            color: #448aff !important; /* Ikon ikut jadi biru */
        }

        /* Penyesuaian Menu Saat Sidebar Mengecil */
        #sidebar.collapsed ul li a {
            margin: 6px 12px;
            padding: 12px 0;
            border-radius: 12px; /* Berubah jadi kotak rounded sempit */
            justify-content: center;
        }

        #sidebar.collapsed ul li a i {
            margin-right: 0;
            font-size: 1.25rem;
        }

        /* AREA KONTEN KANAN */
        #content {
            width: 100%;
            min-height: 100vh;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* TOP NAVBAR STYLING */
        .navbar-custom {
            background-color: #fff;
            box-shadow: 0 2px 15px rgba(0,0,0,.03);
            padding: 15px 30px;
        }

        .btn-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            color: #526484;
            cursor: pointer;
            padding: 0;
            display: flex;
            align-items: center;
            transition: color 0.2s;
        }
        
        .btn-toggle:hover {
            color: #448aff;
        }
    </style>
</head>
<body>

<div class="wrapper">