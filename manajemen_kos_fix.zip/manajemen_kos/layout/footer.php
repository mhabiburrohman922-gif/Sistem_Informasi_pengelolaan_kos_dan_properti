</div> <footer class="footer mt-auto py-3 bg-white border-top text-center text-muted small">
        <div class="container">
            <span>© 2026 <strong>SmartKos System</strong> - Proyek Akhir Basis Data MVP.</span>
        </div>
    </footer>

</div> </div> <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const sidebar = document.getElementById('sidebar');
        const sidebarCollapseBtn = document.getElementById('sidebarCollapse');

        sidebarCollapseBtn.addEventListener('click', function() {
            // Pasang atau lepas class .collapsed pada element sidebar
            sidebar.classList.toggle('collapsed');
        });
    });
</script>
</body>
</html>