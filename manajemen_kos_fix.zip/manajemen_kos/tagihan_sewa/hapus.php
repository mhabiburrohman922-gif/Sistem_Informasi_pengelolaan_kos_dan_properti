<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_tagihan = mysqli_real_escape_string($koneksi, $_GET['id']);

    // Query hapus tagihan berdasarkan ID
    $query_hapus = "DELETE FROM tagihan_sewa WHERE id_tagihan = '$id_tagihan'";

    if (mysqli_query($koneksi, $query_hapus)) {
        echo "<script>alert('Data tagihan berhasil dihapus!'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus tagihan: " . mysqli_error($koneksi) . "'); window.location='index.php';</script>";
    }
} else {
    header("Location: index.php");
}
exit;   