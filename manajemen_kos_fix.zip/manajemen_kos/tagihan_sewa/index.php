<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// Query yang sudah disesuaikan dengan skema kolom database kamu
$query = "SELECT tagihan_sewa.*, kontrak_sewa.id_kamar, penyewa.nama_penyewa, kamar.nomor_kamar 
          FROM tagihan_sewa
          JOIN kontrak_sewa ON tagihan_sewa.id_kontrak = kontrak_sewa.id_kontrak
          JOIN penyewa ON kontrak_sewa.id_penyewa = penyewa.id_penyewa
          JOIN kamar ON kontrak_sewa.id_kamar = kamar.id_kamar
          ORDER BY tagihan_sewa.tahun DESC, tagihan_sewa.bulan DESC";

$result = mysqli_query($koneksi, $query);

include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h3 class="fw-bold text-dark mb-1">Data Tagihan Sewa</h3>
            <p class="text-muted small">Kelola seluruh tagihan bulanan dan status pembayaran penghuni kos.</p>
        </div>
        <div class="col-auto">
            <a href="generate.php" class="btn btn-primary px-4 rounded-3">
                <i class="fa-solid fa-sync me-1"></i> Generate Tagihan Bulanan
            </a>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">NO</th>
                            <th>NAMA PENYEWA</th>
                            <th>NOMOR KAMAR</th>
                            <th>BULAN / TAHUN</th>
                            <th>TOTAL TAGIHAN</th>
                            <th>STATUS</th>
                            <th width="12%" class="text-center">AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        while($row = mysqli_fetch_assoc($result)): 
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td class="fw-bold"><?= $row['nama_penyewa']; ?></td>
                            <td><span class="badge bg-secondary rounded-pill">Kamar <?= $row['nomor_kamar']; ?></span></td>
                            <td><?= $row['bulan'] . ' / ' . $row['tahun']; ?></td>
                            <td class="fw-semibold text-dark">Rp <?= number_format($row['jumlah_tagihan'], 0, ',', '.'); ?></td>
                            <td>
                                <?php if(strtolower($row['status_bayar']) == 'lunas'): ?>
                                    <span class="badge bg-success">Lunas</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><?= $row['status_bayar']; ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <div class="d-flex gap-2 justify-content-center">
                                    <?php if(strtolower($row['status_bayar']) != 'lunas'): ?>
                                        <a href="bayar.php?id=<?= $row['id_tagihan']; ?>" class="btn btn-sm btn-success px-2 rounded-2" title="Set Lunas">
                                            <i class="fa-solid fa-money-bill-wave me-1"></i> Bayar
                                        </a>
                                    <?php endif; ?>
                                    <a href="hapus.php?id=<?= $row['id_tagihan']; ?>" class="btn btn-sm btn-outline-danger px-2 rounded-2" onclick="return confirm('Hapus tagihan ini?')" title="Hapus">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; if(mysqli_num_rows($result) == 0): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">Belum ada data tagihan sewa.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>    