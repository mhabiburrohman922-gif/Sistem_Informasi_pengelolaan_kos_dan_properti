<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// Ambil bulan dan tahun berjalan saat ini
$bulan_sekarang = date('F'); 
$tahun_sekarang = date('Y');

// Query Utama: Hubungkan kontrak_sewa -> kamar -> tipe_kamar untuk ambil tarif_bulanan
$query_kontrak = "SELECT kontrak_sewa.id_kontrak, tipe_kamar.tarif_bulanan 
                  FROM kontrak_sewa 
                  JOIN kamar ON kontrak_sewa.id_kamar = kamar.id_kamar 
                  JOIN tipe_kamar ON kamar.id_tipe = tipe_kamar.id_tipe
                  WHERE kontrak_sewa.status_kontrak = 'Aktif'";
                  
$result_kontrak = mysqli_query($koneksi, $query_kontrak);

if (!$result_kontrak) {
    die("Gagal mengambil data kontrak: " . mysqli_error($koneksi));
}

$jumlah_terbuat = 0;

// Looping untuk buat tagihan baru
while ($kontrak = mysqli_fetch_assoc($result_kontrak)) {
    $id_kontrak = $kontrak['id_kontrak'];
    $tarif = $kontrak['tarif_bulanan'];
    $tgl_jatuh_tempo = date('Y-m-d', strtotime('+14 days')); // Jatuh tempo 14 hari dari sekarang

    // Cek biar tidak ada duplikasi tagihan di bulan dan tahun yang sama
    $cek_tagihan = "SELECT id_tagihan FROM tagihan_sewa 
                    WHERE id_kontrak = '$id_kontrak' AND bulan = '$bulan_sekarang' AND tahun = '$tahun_sekarang'";
    $res_cek = mysqli_query($koneksi, $cek_tagihan);

    if (mysqli_num_rows($res_cek) == 0) {
        // Insert data tagihan baru ke database
        $query_insert = "INSERT INTO tagihan_sewa (id_kontrak, bulan, tahun, jumlah_tagihan, tanggal_jatuh_tempo, status_bayar) 
                         VALUES ('$id_kontrak', '$bulan_sekarang', '$tahun_sekarang', '$tarif', '$tgl_jatuh_tempo', 'Belum Lunas')";
        mysqli_query($koneksi, $query_insert);
        $jumlah_terbuat++;
    }
}

// Balikin notifikasi ke halaman index.php
if ($jumlah_terbuat > 0) {
    echo "<script>alert('Berhasil membuat $jumlah_terbuat tagihan baru untuk periode $bulan_sekarang $tahun_sekarang!'); window.location='index.php';</script>";
} else {
    echo "<script>alert('Semua tagihan untuk periode $bulan_sekarang $tahun_sekarang sudah digenerate sebelumnya.'); window.location='index.php';</script>";
}
exit;