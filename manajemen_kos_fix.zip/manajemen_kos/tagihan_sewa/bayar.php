<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

// Pastikan ada ID tagihan yang dikirim (misal lewat URL: bayar.php?id=... )
if (isset($_GET['id'])) {
    $id_tagihan = mysqli_real_escape_string($koneksi, $_GET['id']);

    // 1. Ambil nominal jumlah_tagihan dari database terlebih dahulu
    $query_cari_tagihan = mysqli_query($koneksi, "SELECT jumlah_tagihan FROM tagihan_sewa WHERE id_tagihan = '$id_tagihan'");
    $data_tagihan = mysqli_fetch_assoc($query_cari_tagihan);

    if ($data_tagihan) {
        $jumlah_bayar   = $data_tagihan['jumlah_tagihan'];
        $tanggal_sekarang = date('Y-m-d'); // Mengambil tanggal hari ini otomatis

        // 2. TAHAP PERTAMA: Ubah status tagihan menjadi Lunas
        $update_tagihan = mysqli_query($koneksi, "UPDATE tagihan_sewa SET status_bayar = 'Lunas' WHERE id_tagihan = '$id_tagihan'");

        if ($update_tagihan) {
            
            // 3. TAHAP KEDUA: Masukkan log data ke dalam tabel pembayaran_sewa biar DB terisi!
            $insert_pembayaran = mysqli_query($koneksi, "INSERT INTO pembayaran_sewa (id_tagihan, tanggal_bayar, jumlah_bayar) 
                                                         VALUES ('$id_tagihan', '$tanggal_sekarang', '$jumlah_bayar')");

            if ($insert_pembayaran) {
                // Jika sukses semua, langsung lempar ke halaman riwayat pembayaran
                echo "<script>
                        alert('Pembayaran Berhasil dan Tercatat di Database!');
                        window.location.href = '../pembayaran/index.php';
                      </script>";
            } else {
                echo "Gagal memasukkan data ke tabel pembayaran_sewa: " . mysqli_error($koneksi);
            }

        } else {
            echo "Gagal memperbarui status tagihan: " . mysqli_error($koneksi);
        }
    } else {
        echo "Data tagihan tidak ditemukan!";
    }
} else {
    echo "ID Tagihan tidak valid atau tidak ditemukan!";
}
?>