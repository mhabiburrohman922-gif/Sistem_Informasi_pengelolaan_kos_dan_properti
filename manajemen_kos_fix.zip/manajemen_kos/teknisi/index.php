<?php
include '../layout/header.php';
include '../layout/sidebar.php';
include '../config/koneksi.php';
/** @var mysqli $koneksi */
// Ambil data dari tabel teknisi_properti
$query = "SELECT * FROM teknisi_properti ORDER BY id_teknisi DESC";
$result = mysqli_query($koneksi, $query);
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Data Teknisi Properti</h3>
                <p class="text-muted small mb-0">Daftar teknisi yang menangani perawatan dan perbaikan fasilitas kos.</p>
            </div>
            <a href="tambah.php" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">
                <i class="fa-solid fa-plus me-2"></i>Tambah Teknisi
            </a>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light text-secondary">
                            <tr>
                                <th width="60" class="text-center">No</th>
                                <th>Nama Teknisi</th>
                                <th>Keahlian</th>
                                <th>No. HP</th>
                                <th width="150" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            if (mysqli_num_rows($result) > 0) :
                                while ($row = mysqli_fetch_assoc($result)) : 
                            ?>
                                <tr>
                                    <td class="text-center fw-semibold"><?= $no++; ?></td>
                                    <td><span class="fw-bold text-dark"><?= htmlspecialchars($row['nama_teknisi']); ?></span></td>
                                    <td><span class="badge bg-secondary text-white"><?= htmlspecialchars($row['keahlian']); ?></span></td>
                                    <td><?= htmlspecialchars($row['telepon_teknisi']); ?></td>
                                    <td class="text-center">
                                        <div class="btn-group gap-1">
                                            <a href="edit.php?id=<?= $row['id_teknisi']; ?>" class="btn btn-sm btn-outline-warning rounded-2"><i class="fa-solid fa-pen-to-square"></i></a>
                                            <a href="hapus.php?id=<?= $row['id_teknisi']; ?>" class="btn btn-sm btn-outline-danger rounded-2" onclick="return confirm('Hapus data teknisi?')"><i class="fa-solid fa-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php 
                                endwhile; 
                            else : 
                            ?>
                                <tr><td colspan="5" class="text-center py-4 text-muted">Belum ada data teknisi.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>