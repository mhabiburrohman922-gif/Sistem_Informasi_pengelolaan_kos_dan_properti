<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

if (isset($_POST['simpan'])) {
    $nama_teknisi = mysqli_real_escape_string($koneksi, $_POST['nama_teknisi']);
    $keahlian     = mysqli_real_escape_string($koneksi, $_POST['keahlian']);
    $no_telp      = mysqli_real_escape_string($koneksi, $_POST['no_telp']);

    $query = "INSERT INTO teknisi_properti (nama_teknisi, keahlian, no_telp) 
              VALUES ('$nama_teknisi', '$keahlian', '$no_telp')";
              
    $simpan = mysqli_query($koneksi, $query);
    
    if ($simpan) {
        echo "<script>alert('Teknisi berhasil ditambahkan!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Gagal menambah data: " . mysqli_error($koneksi) . "');</script>";
    }
}

include '../layout/header.php';
include '../layout/sidebar.php';
?>

<div class="container-fluid mb-5 px-4">
    <div class="row mb-4">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <div>
                <h3 class="fw-bold text-dark mb-1">Tambah Teknisi Baru</h3>
                <p class="text-muted small mb-0">Input data teknisi atau tukang perbaikan kos.</p>
            </div>
            <a href="index.php" class="btn btn-light border px-4 py-2 rounded-3 shadow-sm">
                <i class="fa-solid fa-arrow-left me-2"></i>Kembali
            </a>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-4">
            <form action="" method="POST">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-secondary">NAMA TEKNISI</label>
                        <input type="text" name="nama_teknisi" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" placeholder="Contoh: Pak Eko" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-secondary">NOMOR TELEPON / WA</label>
                        <input type="text" name="no_telp" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" placeholder="Contoh: 081234xxxxx" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold text-secondary">KEAHLIAN / SPESIALISASI</label>
                        <input type="text" name="keahlian" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6" placeholder="Contoh: Ahli AC, Kelistrikan, Air, Tukang Bangunan" required>
                    </div>
                </div>
                <div class="d-flex justify-content-end gap-2 mt-4">
                    <a href="index.php" class="btn btn-light px-4 py-2 rounded-3">Batal</a>
                    <button type="submit" name="simpan" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../layout/footer.php'; ?>