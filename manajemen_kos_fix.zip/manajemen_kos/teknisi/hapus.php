<?php
include '../config/koneksi.php';
/** @var mysqli $koneksi */

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_teknisi = mysqli_real_escape_string($koneksi, $_GET['id']);
    
    $query = "DELETE FROM teknisi_properti WHERE id_teknisi = '$id_teknisi'";
    $hapus = mysqli_query($koneksi, $query);
    
    if ($hapus) {
        echo "<script>alert('Data teknisi berhasil dihapus!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data: " . mysqli_error($koneksi) . "'); window.location.href='index.php';</script>";
    }
} else {
    echo "<script>window.location.href='index.php';</script>";
}
?>