<?php
// Pengaturan koneksi database
$host     = "sql110.infinityfree.com";
$user     = "if0_42357606";
$password = "m2hxs7P2SwaCZDq";
$database = "if0_42357606_manajemen_kos";

// Proses menghubungkan ke database
$koneksi = mysqli_connect($host, $user, $password, $database);

if (mysqli_connect_errno()) {
    echo "Koneksi database gagal: " . mysqli_connect_error();
}
?>
