    <?php 
    // Naik satu tingkat ke folder config dan layout agar CSS terpanggil dengan benar
    include '../config/koneksi.php'; 
    include '../layout/header.php';
    include '../layout/sidebar.php';
    ?>

    <div class="container-fluid mb-5">
        <div class="d-flex justify-content-between mb-4 align-items-center">
            <div>
                <h2>Manajemen Kamar</h2>
                <p class="text-muted small mb-0">Kelola informasi data kamar dan tarif bulanan kos.</p>
            </div>
            <a href="tambah.php" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Tambah Kamar</a>
        </div>

        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped align-middle">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nomor Kamar</th>
                            <th>Tipe</th>
                            <th>Tarif</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
/** @var mysqli $koneksi */

                        $sql = "SELECT k.*, t.nama_tipe, t.tarif_bulanan 
                                FROM kamar k 
                                JOIN tipe_kamar t ON k.id_tipe = t.id_tipe";
                        $result = mysqli_query($koneksi, $sql);
                        $no = 1;
                        
                        if ($result && mysqli_num_rows($result) > 0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                // Menentukan warna badge berdasarkan status
                                $status = strtolower($row['status_kamar']);
                                if ($status == 'tersedia' || $status == 'kosong') {
                                    $badge = "bg-success";
                                } elseif ($status == 'terisi' || $status == 'penuh') {
                                    $badge = "bg-danger";
                                } else {
                                    $badge = "bg-info";
                                }

                                echo "<tr>
                                    <td>{$no}</td>
                                    <td><strong>Kamar {$row['nomor_kamar']}</strong></td>
                                    <td>{$row['nama_tipe']}</td>
                                    <td>Rp " . number_format($row['tarif_bulanan'], 0, ',', '.') . "</td>
                                    <td><span class='badge {$badge}'>{$row['status_kamar']}</span></td>
                                    <td>
                                        <a href='edit.php?id={$row['id_kamar']}' class='btn btn-sm btn-warning'><i class='fa-solid fa-pen-to-square'></i> Edit</a>
                                        <a href='hapus.php?id={$row['id_kamar']}' class='btn btn-sm btn-danger' onclick=\"return confirm('Yakin ingin menghapus kamar ini?')\"><i class='fa-solid fa-trash'></i> Hapus</a>
                                    </td>
                                </tr>";
                                $no++;
                            }
                        } else {
                            echo "<tr><td colspan='6' class='text-center py-4 text-muted'>Belum ada data kamar tersedia. Silakan klik tombol 'Tambah Kamar'.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php include '../layout/footer.php'; ?>