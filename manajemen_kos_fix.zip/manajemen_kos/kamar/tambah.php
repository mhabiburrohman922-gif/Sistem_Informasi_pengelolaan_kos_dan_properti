<?php 
// 1. AKTIFKAN ERROR REPORTING (Biar kalau error gak blank putih lagi)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2. KOREKSI JALUR INCLUDE (Naik satu tingkat keluar dari folder kamar)
include_once '../config/koneksi.php'; 
include_once '../layout/header.php';
include_once '../layout/sidebar.php';
/** @var mysqli $koneksi */

if (isset($_POST['simpan'])) {
    $nomor_kamar  = mysqli_real_escape_string($koneksi, $_POST['nomor_kamar']);
    $id_tipe      = mysqli_real_escape_string($koneksi, $_POST['id_tipe']);
    $status_kamar = mysqli_real_escape_string($koneksi, $_POST['status_kamar']);

    // Pastikan nama kolom di database sesuai: id_tipe atau id_tipe_kamar? 
    $query  = "INSERT INTO kamar (nomor_kamar, id_tipe, status_kamar) VALUES ('$nomor_kamar', '$id_tipe', '$status_kamar')";
    $simpan = mysqli_query($koneksi, $query);

    if ($simpan) {
        echo "<script>
                alert('Data kamar berhasil ditambahkan!');
                window.location='index.php';
              </script>";
        exit;
    } else {
        // Jika insert gagal karena database, akan memunculkan pesan error sql aslinya
        echo "<script>
                alert('Gagal menambahkan data kamar! Error: " . mysqli_error($koneksi) . "');
              </script>";
    }
}
?>

<style>
    .custom-label {
        font-size: 0.85rem;
        font-weight: 700;
        color: #2c3e50;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
    }
    .custom-input {
        background-color: #f8f9fa !important;
        border: 1px solid #e9ecef !important;
        padding: 12px 16px;
        border-radius: 8px;
        color: #495057;
    }
    .custom-input:focus {
        background-color: #fff !important;
        border-color: #3b71ca !important;
        box-shadow: 0 0 0 0.25rem rgba(59, 113, 202, 0.1) !important;
    }
    .card-custom {
        border-radius: 16px;
        border: none;
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.02) !important;
    }
    .btn-simpan {
        background-color: #0d6efd;
        color: white;
        border-radius: 10px;
        padding: 10px 24px;
        font-weight: 600;
        border: none;
    }
    .btn-simpan:hover {
        background-color: #0b5ed7;
        color: white;
    }
    .btn-batal {
        background-color: #f8f9fa;
        color: #6c757d;
        border-radius: 10px;
        padding: 10px 24px;
        font-weight: 600;
        border: 1px solid #e9ecef;
    }
    .btn-batal:hover {
        background-color: #e2e6ea;
        color: #495057;
    }
</style>

<div class="container-fluid mb-5 px-4">
    <div class="d-flex justify-content-between mb-4 align-items-center">
        <h2 class="fw-bold" style="color: #1e293b;">Form Tambah Kamar Baru</h2>
        <a href="index.php" class="btn btn-light btn-sm text-muted px-3 py-2 border" style="border-radius: 8px;">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali
        </a>
    </div>

    <div class="card card-custom bg-white p-2">
        <div class="card-body p-4">
            <form action="" method="POST">
                
                <div class="row mb-4">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <label class="form-label custom-label">Nomor / Kode Kamar</label>
                        <input type="text" name="nomor_kamar" placeholder="Contoh: B-001" required class="form-control custom-input">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label custom-label">Tipe Kamar (Kategori)</label>
                        <select name="id_tipe" required class="form-select custom-input">
                            <option value="" disabled selected>Pilih Tipe Kamar</option>
                            <?php
                            $tipe = mysqli_query($koneksi, "SELECT * FROM tipe_kamar");
                            if ($tipe) {
                                while($t = mysqli_fetch_array($tipe)) {
                                    // Cek apakah kolom di tabel tipe_kamar-mu namanya 'tarif_bulanan' atau 'harga'
                                    $tarif = isset($t['tarif_bulanan']) ? $t['tarif_bulanan'] : 0;
                                    echo "<option value='".$t['id_tipe']."'>".$t['nama_tipe']." — Rp ".number_format($tarif, 0, ',', '.')."</option>";
                                }
                            } else {
                                echo "<option value='' disabled>Gagal memuat tipe kamar: " . mysqli_error($koneksi) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-5">
                    <div class="col-md-6">
                        <label class="form-label custom-label">Status Kamar</label>
                        <select name="status_kamar" class="form-select custom-input">
                            <option value="Tersedia">Tersedia</option>
                            <option value="Terisi">Terisi</option>
                            <option value="Pemeliharaan">Pemeliharaan</option>
                        </select>
                    </div>
                </div>
                
                <div class="d-flex justify-content-end gap-2 mt-4">
                    <a href="index.php" class="btn btn-batal">Batal</a>
                    <button type="submit" name="simpan" class="btn btn-simpan">Simpan Kamar</button>
                </div>

            </form>
        </div>
    </div>
</div>

<?php include_once '../layout/footer.php'; ?>