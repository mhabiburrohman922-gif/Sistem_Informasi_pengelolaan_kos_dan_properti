<?php
include '../config/koneksi.php';

/** @var mysqli $koneksi */

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_kamar = mysqli_real_escape_string($koneksi, $_GET['id']);

    // Proses eksekusi query hapus
    $query_hapus = "DELETE FROM kamar WHERE id_kamar = '$id_kamar'";
    $hapus = mysqli_query($koneksi, $query_hapus);

    if ($hapus) {
        echo "<script>
                alert('Kamar berhasil dihapus!');
                window.location='index.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus kamar! Kamar mungkin terikat dengan transaksi sewa aktif.');
                window.location='index.php';
              </script>";
    }
} else {
    echo "<script>window.location='index.php';</script>";
}
?>