<?php
include '../config/koneksi.php';
include '../layout/header.php';
include '../layout/sidebar.php';
/** @var mysqli $koneksi */

// Fitur Hapus Kamar
if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus') {
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);
    $hapus = mysqli_query($koneksi, "DELETE FROM kamar WHERE id_kamar = '$id'");
    if ($hapus) {
        echo "<script>alert('Kamar berhasil dihapus!'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus kamar: " . mysqli_error($koneksi) . "');</script>";
    }
}

// Ambil Data Kamar yang Mau Diedit
$id = mysqli_real_escape_string($koneksi, $_GET['id']);
$data = mysqli_query($koneksi, "SELECT * FROM kamar WHERE id_kamar = '$id'");
$row = mysqli_fetch_array($data);

// Fitur Proses Update Kamar
if (isset($_POST['update'])) {
    $nomor_kamar = mysqli_real_escape_string($koneksi, $_POST['nomor_kamar']);
    $id_tipe     = mysqli_real_escape_string($koneksi, $_POST['id_tipe']);
    $status      = mysqli_real_escape_string($koneksi, $_POST['status']);

    // KOREKSI: Mengubah kolom 'status' menjadi 'status_kamar' sesuai skema database asli
    $update = mysqli_query($koneksi, "UPDATE kamar SET nomor_kamar='$nomor_kamar', id_tipe='$id_tipe', status_kamar='$status' WHERE id_kamar='$id'");
    
    if ($update) {
        echo "<script>alert('Data kamar berhasil diubah!'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal mengubah data kamar: " . mysqli_error($koneksi) . "');</script>";
    }
}
?>

<div class="content">
    <h2>Edit Data Kamar</h2>
    <form action="" method="POST">
        <div class="form-group">
            <label>Nomor Kamar</label>
            <input type="text" name="nomor_kamar" value="<?= $row['nomor_kamar']; ?>" required class="form-control">
        </div>
        
        <div class="form-group">
            <label>Tipe Kamar</label>
            <select name="id_tipe" required class="form-control">
                <?php
                /** @var mysqli $koneksi */
                $tipe = mysqli_query($koneksi, "SELECT * FROM tipe_kamar");
                while($t = mysqli_fetch_array($tipe)) {
                    // Membuat tipe yang tersimpan otomatis terpilih (selected)
                    $selected = ($t['id_tipe'] == $row['id_tipe']) ? 'selected' : '';
                    echo "<option value='".$t['id_tipe']."' $selected>".$t['nama_tipe']."</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label>Status Kamar</label>
            <select name="status" class="form-control">
                <!-- KOREKSI: Mengubah penanganan array dari $row['status'] menjadi $row['status_kamar'] -->
                <option value="Tersedia" <?= ($row['status_kamar'] == 'Tersedia') ? 'selected' : ''; ?>>Tersedia</option>
                <option value="Terisi" <?= ($row['status_kamar'] == 'Terisi') ? 'selected' : ''; ?>>Terisi</option>
                <option value="Pemeliharaan" <?= ($row['status_kamar'] == 'Pemeliharaan') ? 'selected' : ''; ?>>Pemeliharaan</option>
            </select>
        </div>
        
        <br>
        <button type="submit" name="update" class="btn btn-success">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../layout/footer.php'; ?>